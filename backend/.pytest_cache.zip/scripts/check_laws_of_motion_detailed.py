from app.core.database import supabase
from app.api.v1.quizzes import normalize_name, get_db_chapter

chapter = "Laws of Motion"
db_chapter = get_db_chapter(chapter)
print(f"Checking for chapter: '{chapter}' -> DB Name: '{db_chapter}'")

try:
    print(f"Querying common_test_questions for chapter='{db_chapter}'...")
    res = supabase.table("common_test_questions").select("id, question").eq("chapter", db_chapter).execute()
    
    count = len(res.data) if res.data else 0
    print(f"Found {count} questions in 'common_test_questions'.")
    if count > 0:
        print(f"Sample Question: {res.data[0].get('question')}")
    else:
        # Check standard questions as fallback logic might use them?
        print(f"Checking 'learning_content' table as backup...")
        res_lc = supabase.table("learning_content").select("id").eq("chapter", db_chapter).limit(5).execute()
        lc_count = len(res_lc.data) if res_lc.data else 0
        print(f"Found {lc_count} questions in 'learning_content'.")

except Exception as e:
    print(f"Error: {e}")
