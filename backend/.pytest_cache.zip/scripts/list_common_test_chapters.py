from app.core.database import supabase

try:
    print("Fetching distinct chapters from `common_test_questions`...")
    # Fetch all chapters (not efficient for huge DBs but fine here)
    res = supabase.table("common_test_questions").select("chapter").execute()
    
    if not res.data:
        print("Table `common_test_questions` is EMPTY.")
    else:
        chapters = set(row['chapter'] for row in res.data if row.get('chapter'))
        print(f"Found {len(chapters)} distinct chapters:")
        for c in sorted(chapters):
            print(f" - '{c}'")

except Exception as e:
    print(f"Error: {e}")
