from app.core.database import supabase
import sys

# clean output
sys.stdout.reconfigure(encoding='utf-8')

print("Attempting to add 'last_action' column to Supabase 'subtopic_mastery' table via PostgreSQL RPC or raw query...")

# Note: The Supabase Python client doesn't support table alteration directly unless we have a specific RPC function setup for it.
# Or if we have a direct connection string.
# Here we will try to just PRINT the instruction because the user might not have an RPC for this.
# But wait, if I can just execute a raw query?
# There is no 'query' method exposed usually on the client for DDL unless using postgrest-py lower level.

print("\n--- INSTRUCTIONS FOR SUPABASE ---")
print("Since I cannot directly alter the remote Supabase schema via the API client (restricted permissions Usually),")
print("Please run this SQL in your Supabase SQL Editor:")
print("\nALTER TABLE subtopic_mastery ADD COLUMN IF NOT EXISTS last_action VARCHAR;")
print("\n--- END INSTRUCTIONS ---")

# Best effort check if it fails
try:
    # Try to insert a dummy record with last_action to see if it errors
    # Actually, don't pollute the DB.
    pass
except Exception as e:
    pass
