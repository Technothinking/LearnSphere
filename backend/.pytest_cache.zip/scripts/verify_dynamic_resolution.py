import time
from app.api.v1.quizzes import get_db_chapter, _refresh_chapter_lookup, _DB_CHAPTER_CACHE

print("--- Testing Dynamic Chapter Resolution ---")

# 1. Force refresh
print("Refreshing cache...")
_refresh_chapter_lookup()
print(f"Cache size: {len(_DB_CHAPTER_CACHE)}")

# 2. Test "Laws of Motion" (normalized input)
input_name = "laws of motion"
resolved = get_db_chapter(input_name)
print(f"Input: '{input_name}' -> Resolved: '{resolved}'")

if resolved == "Laws of Motion":
    print("SUCCESS: Resolved correctly to DB casing.")
else:
    print(f"FAILURE: Resolved to '{resolved}'")

# 3. Test "Work and Energy" (exact match in map, but let's see if cache handles it too if map didn't have it)
# The current logic checks MAP first.
# Let's test a hypothetical new chapter that IS NOT in the map but IS in the DB.
# Since I can't easily add to DB here, I will rely on the fact that Laws of Motion IS in the map now (I fixed it earlier).
# Wait, I fixed the map earlier to point to "Laws of Motion". 
# So to test DYNAMIC part, I should temporarily interpret a name that is NOT in the map.
# But I don't want to modify code just for test.
# I will inspect the cache directly to see if it contains "laws of motion".

norm_key = "lawsofmotion"
if norm_key in _DB_CHAPTER_CACHE:
    print(f"Cache Verification: Key '{norm_key}' is present -> '{_DB_CHAPTER_CACHE[norm_key]}'")
else:
    print(f"Cache Verification: Key '{norm_key}' is MISSING.")
