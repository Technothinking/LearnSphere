from app.core.database import supabase

def search_chapters(table_name, search_term):
    print(f"\n--- Searching in: {table_name} for '{search_term}' ---")
    try:
        # Fetching all to be sure we don't miss anything with ILIKE if it's tricky
        res = supabase.table(table_name).select("chapter").execute()
        if res.data:
            chapters = set([d['chapter'] for d in res.data if d.get('chapter')])
            matches = [c for c in chapters if search_term.lower() in c.lower()]
            if matches:
                for m in matches:
                    print(f" Found: '{m}'")
            else:
                print(" No matches found.")
        else:
            print(" Table is empty.")
    except Exception as e:
        print(f" Error searching {table_name}: {e}")

for table in ["common_test_questions", "learning_content", "textbook"]:
    search_chapters(table, "Motion")
    search_chapters(table, "Law")
