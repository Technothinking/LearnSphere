from app.core.database import SessionLocal
from app.models.mastery import SubtopicMastery
from app.models.performance import PerformanceHistory
from app.api.v1.quizzes import submit_adaptive_test
from app.schemas.quiz_schema import AdaptiveTestSubmission
import uuid

def verify_mastery():
    db = SessionLocal()
    student_id = f"test_student_{uuid.uuid4().hex[:8]}"
    chapter = "Laws of Motion"
    
    # 1. Simulate Common Test Submission
    # Subtopic 1: "Newton's Laws of Motion" (Good performance)
    # Subtopic 2: "Speed and Velocity" (Bad performance)
    
    print(f"Submitting test for student {student_id}...")
    
    submission_data = {
        "student_id": student_id,
        "chapter": chapter,
        "subtopic": "", # Common Test
        "difficulty_level": 0,
        "score": 5,
        "total_questions": 10,
        "time_taken": 100,
        "answers": [
            {"question_id": 1, "is_correct": True, "topic": "Newton's Laws of Motion and Related Equations"},
            {"question_id": 2, "is_correct": True, "topic": "Newton's Laws of Motion and Related Equations"}, # 100%
            {"question_id": 3, "is_correct": False, "topic": "Speed and Velocity"},
            {"question_id": 4, "is_correct": False, "topic": "Speed and Velocity"}, # 0%
        ]
    }
    
    try:
        # We need to mock the request context or just call the logic?
        # calling the function directly requires a Pydantic model
        submission = AdaptiveTestSubmission(**submission_data)
        submit_adaptive_test(submission, db)
        
        # 2. Verify SubtopicMastery
        print("\nVerifying Subtopic Mastery...")
        
        # Good Subtopic
        m_good = db.query(SubtopicMastery).filter(
            SubtopicMastery.student_id == student_id,
            SubtopicMastery.subtopic == "Newton's Laws of Motion and Related Equations"
        ).first()
        
        if m_good:
            print(f"Good Subtopic: Level={m_good.level}, Action={m_good.last_action}, Acc={m_good.accuracy}")
            if m_good.level > 0 and m_good.last_action == "ADVANCE":
                print("✅ Good Subtopic Verified")
            else:
                print("❌ Good Subtopic Failed")
        else:
            print("❌ Good Subtopic Record Not Found")

        # Bad Subtopic
        m_bad = db.query(SubtopicMastery).filter(
            SubtopicMastery.student_id == student_id,
            SubtopicMastery.subtopic == "Speed and Velocity"
        ).first()
        
        if m_bad:
            print(f"Bad Subtopic: Level={m_bad.level}, Action={m_bad.last_action}, Acc={m_bad.accuracy}")
            # Level might be 0, Action RETRY
            if m_bad.last_action == "RETRY":
                print("✅ Bad Subtopic Verified")
            else:
                print("❌ Bad Subtopic Failed")
        else:
            print("❌ Bad Subtopic Record Not Found")
            
        # 3. Verify PerformanceHistory
        print("\nVerifying Performance History...")
        perf = db.query(PerformanceHistory).filter(
            PerformanceHistory.student_id == student_id,
            PerformanceHistory.chapter == chapter
        ).all()
        
        if perf:
            has_null = False
            for p in perf:
                print(f"Perf ID: {p.id}, Topic: {p.subtopic}")
                if not p.subtopic:
                    has_null = True
            
            if not has_null:
                print("✅ All Performance Records have Topic")
            else:
                print("❌ Some Performance Records missing Topic")
        else:
            print("❌ No Performance Records Found")

    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

if __name__ == "__main__":
    verify_mastery()
