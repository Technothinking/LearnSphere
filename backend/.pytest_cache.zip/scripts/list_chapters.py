from app.core.database import supabase

def get_unique_chapters(table_name):
    print(f"\n--- Table: {table_name} ---")
    try:
        res = supabase.table(table_name).select("chapter").execute()
        if res.data:
            chapters = sorted(list(set([d['chapter'] for d in res.data if d.get('chapter')])))
            for c in chapters:
                print(f" - {c}")
        else:
            print("Table is empty.")
    except Exception as e:
        print(f"Error inspecting {table_name}: {e}")

get_unique_chapters("common_test_questions")
get_unique_chapters("learning_content")
get_unique_chapters("textbook")
