from app.core.database import supabase
import sys

# clean output
sys.stdout.reconfigure(encoding='utf-8')

res = supabase.table("common_test_questions").select("chapter").eq("chapter", "Laws of Motion").execute()
if res.data:
    print(f"Query for 'Laws of Motion' (lowercase o) found {len(res.data)} rows.")
    print(f"Raw value: {res.data[0]['chapter']}")
else:
    print("Query for 'Laws of Motion' (lowercase o) found NOTHING.")

res2 = supabase.table("common_test_questions").select("chapter").eq("chapter", "Laws Of Motion").execute()
if res2.data:
    print(f"Query for 'Laws Of Motion' (uppercase O) found {len(res2.data)} rows.")
else:
    print("Query for 'Laws Of Motion' (uppercase O) found NOTHING.")
