import sqlite3
import os

db_path = "d:/PORJECT/Reducate/backend/sql_app.db"

def check_table(cursor, table_name):
    print(f"\nTable: {table_name}")
    cursor.execute(f"PRAGMA table_info({table_name})")
    cols = cursor.fetchall()
    for col in cols:
        print(f"  {col[1]}")

conn = sqlite3.connect(db_path)
cursor = conn.cursor()
check_table(cursor, "subtopic_mastery")
check_table(cursor, "students")
conn.close()
