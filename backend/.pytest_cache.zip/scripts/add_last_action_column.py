from app.core.database import SessionLocal
from sqlalchemy import text

def add_column():
    session = SessionLocal()
    try:
        print("Attempting to add 'last_action' column to 'subtopic_mastery' table...")
        session.execute(text("ALTER TABLE subtopic_mastery ADD COLUMN last_action VARCHAR"))
        session.commit()
        print("SUCCESS: Column added.")
    except Exception as e:
        print(f"Error: {e}")
        # It might fail if column already exists (though my check said it didn't)
    finally:
        session.close()

if __name__ == "__main__":
    add_column()
