import requests
import json

base_url = "http://localhost:8001/api/v1"
student_id = "d16a5111-8fb7-4c22-bc4f-3ca587ed65f0"

def test_endpoint(path):
    print(f"\nTesting: {path}")
    try:
        r = requests.get(f"{base_url}{path}")
        print(f"Status: {r.status_code}")
        if r.status_code == 200:
             print(f"Data count: {len(r.json())}")
             print(f"First item: {r.json()[0] if r.json() else 'None'}")
        else:
             print(f"Response: {r.text}")
    except Exception as e:
        print(f"Error: {e}")

test_endpoint("/quizzes/subjects")
test_endpoint(f"/quizzes/subjects?student_id={student_id}")
test_endpoint("/quizzes/chapters?subject=Science")
test_endpoint(f"/quizzes/check-diagnostic/{student_id}")
