from app.api.v1.quizzes import normalize_name, get_db_chapter, CHAPTER_NAME_MAP, NORMALIZED_CHAPTER_MAP

def test_normalization():
    test_cases = [
        "Laws of Motion",
        "Laws Of Motion",
        "laws of motion",
        "Laws  of  Motion",
        "LAWS OF MOTION",
        "Work and Energy",
        "Work And Energy",
        "Acids, Bases and Salts"
    ]
    
    print(f"{'Input':<30} | {'Resolved DB Chapter':<30} | {'Match?'}")
    print("-" * 75)
    for tc in test_cases:
        resolved = get_db_chapter(tc)
        print(f"{tc:<30} | {resolved:<30} | {'Pass' if resolved else 'Fail'}")

print("--- Testing Normalization ---")
test_normalization()

print("\n--- Normalized Map ---")
# Print a few to check
for k, v in list(NORMALIZED_CHAPTER_MAP.items())[:5]:
    print(f"{k} -> {v}")
