import sqlite3
import os

db_path = "d:/PORJECT/Reducate/backend/sql_app.db"

if not os.path.exists(db_path):
    print(f"Error: Database not found at {db_path}")
    exit(1)

def check_table(cursor, table_name):
    print(f"\nScanning table: {table_name}")
    cursor.execute(f"PRAGMA table_info({table_name})")
    cols = cursor.fetchall()
    for col in cols:
        print(f"  - {col[1]} ({col[2]})")

try:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    check_table(cursor, "students")
    check_table(cursor, "performance_history")
    check_table(cursor, "subtopic_mastery")
    
    conn.close()
except Exception as e:
    print(f"Verification failed: {e}")
