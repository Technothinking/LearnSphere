from app.core.database import supabase
import sys

# clean output
sys.stdout.reconfigure(encoding='utf-8')

try:
    print("--- Fetching Common Test Chapters ---")
    res = supabase.table("common_test_questions").select("chapter").execute()
    
    if not res.data:
        print("[EMPTY] Table common_test_questions has no rows.")
    else:
        chapters = set()
        for row in res.data:
            c = row.get('chapter')
            if c:
                chapters.add(c.strip())
        
        print(f"Found {len(chapters)} distinct chapters:")
        for c in sorted(chapters):
            print(f" • '{c}'")

except Exception as e:
    print(f"Error: {e}")
