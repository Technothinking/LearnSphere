from app.api.v1.quizzes import get_db_chapter, CHAPTER_NAME_MAP, get_common_test_questions

chapter = "Laws of Motion"
db_chap = get_db_chapter(chapter)
print(f"Input: '{chapter}' -> DB Chapter: '{db_chap}'")

if db_chap == "Laws of Motion":
    print("SUCCESS: Casing matches DB.")
else:
    print(f"FAILURE: Casing mismatch. Expected 'Laws of Motion', got '{db_chap}'")

# limit 1 just to see if it runs without error
try:
    questions = get_common_test_questions(chapter=chapter, limit=1)
    print(f"Fetched {len(questions)} questions.")
    if len(questions) > 0:
        print("Verification PASSED.")
    else:
        print("Verification FAILED: No questions returned.")
except Exception as e:
    print(f"Verification FAILED with error: {e}")
