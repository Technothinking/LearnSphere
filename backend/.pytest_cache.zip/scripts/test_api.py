import requests
import json

base_url = "http://localhost:8000/api/v1"
student_id = "d16a5111-8fb7-4c22-bc4f-3ca587ed65f0"

def test_endpoint(path):
    print(f"\nTesting: {path}")
    try:
        r = requests.get(f"{base_url}{path}")
        print(f"Status: {r.status_code}")
        print(f"Response: {r.json()}")
    except Exception as e:
        print(f"Error: {e}")

test_endpoint("/quizzes/subjects")
test_endpoint("/quizzes/chapters?subject=Science")
test_endpoint(f"/quizzes/check-diagnostic/{student_id}")
test_endpoint(f"/quizzes/mastery/{student_id}")
test_endpoint("/quizzes/topics?subject=Science&chapter=Acids Bases and Salts")
