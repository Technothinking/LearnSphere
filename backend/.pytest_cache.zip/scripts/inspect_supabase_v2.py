from supabase import create_client, Client
import json

SUPABASE_URL = "https://nhqmomcrcownexdpsizu.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5ocW1vbWNyY293bmV4ZHBzaXp1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk2NDk3NDUsImV4cCI6MjA4NTIyNTc0NX0.Kzce-oOtc1FrgxRhoV5iZdAqTxU7y_2IaTqiT_1kxT0"

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

def inspect_table(table_name):
    print(f"\n--- Table: {table_name} ---")
    try:
        res = supabase.table(table_name).select("*").limit(2).execute()
        if res.data:
            print(f"Columns: {list(res.data[0].keys())}")
            print(f"Sample Row: {res.data[0]}")
        else:
            print("Table has no data.")
    except Exception as e:
        print(f"Error: {e}")

inspect_table("textbook")
inspect_table("learning_content")
inspect_table("student_permissions")
inspect_table("subtopic_mastery")
inspect_table("students")
