import sqlite3
import os

db_path = "d:/PORJECT/Reducate/backend/sql_app.db"

if not os.path.exists(db_path):
    print(f"Error: Database not found at {db_path}")
    exit(1)

try:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Check if column exists
    cursor.execute("PRAGMA table_info(subtopic_mastery)")
    columns = [row[1] for row in cursor.fetchall()]
    
    if "mastery" not in columns:
        print("Adding 'mastery' column to 'subtopic_mastery' table...")
        cursor.execute("ALTER TABLE subtopic_mastery ADD COLUMN mastery FLOAT DEFAULT 0.0")
        conn.commit()
        print("Column added successfully!")
    else:
        print("Column 'mastery' already exists.")
        
    conn.close()
except Exception as e:
    print(f"Failed to migrate database: {e}")
    exit(1)
