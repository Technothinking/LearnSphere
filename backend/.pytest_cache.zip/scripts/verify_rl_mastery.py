from app.core.database import SessionLocal
from app.models.mastery import SubtopicMastery
from app.api.v1.quizzes import submit_adaptive_test
from app.schemas.quiz_schema import AdaptiveTestSubmission
import uuid

def verify_rl_mastery():
    db = SessionLocal()
    student_id = f"test_rl_{uuid.uuid4().hex[:8]}"
    chapter = "Laws of Motion"
    
    # 1. Simulate Test with "Checkable" Performance
    # Subtopic 1: "Newton's Laws" - High Accuracy (100%) -> Rule/RL should Advance
    # Subtopic 2: "Force" - Med Accuracy (60%) -> RL might Retry or Advance depending on input
    
    print(f"Submitting test for student {student_id}...")
    
    # We can't easily mock the RL service here without patching. 
    # But we can check if the logic holds by inspecting the output vs expected behavior if RL was random/rules.
    # Actually, let's just see if it runs without error and produces a result.
    
    submission_data = {
        "student_id": student_id,
        "chapter": chapter,
        "subtopic": "", # Common Test
        "difficulty_level": 1,
        "score": 8,
        "total_questions": 10,
        "time_taken": 100,
        "answers": [
            {"question_id": 1, "is_correct": True, "topic": "Newton's Laws of Motion and Related Equations"},
            {"question_id": 2, "is_correct": True, "topic": "Newton's Laws of Motion and Related Equations"},
            {"question_id": 3, "is_correct": True, "topic": "Newton's Laws of Motion and Related Equations"},
            {"question_id": 4, "is_correct": False, "topic": "Velocity Time Graphs"},
            {"question_id": 5, "is_correct": False, "topic": "Velocity Time Graphs"}
        ]
    }
    
    try:
        submission = AdaptiveTestSubmission(**submission_data)
        response = submit_adaptive_test(submission, db)
        
        print("\n=== RESPONSE VERIFICATION ===")
        print(f"Fallback Topics in Response: {response.fallback_topics}")
        
        if "Velocity Time Graphs" in response.fallback_topics:
             print("✅ 'Velocity Time Graphs' correctly present in fallback_topics")
        else:
             print("❌ 'Velocity Time Graphs' MISSING from fallback_topics")

        print("\n=== DATABASE VERIFICATION ===")
        
        # Check Newton's Laws (100%)
        m_good = db.query(SubtopicMastery).filter(
            SubtopicMastery.student_id == student_id,
            SubtopicMastery.subtopic == "Newton's Laws of Motion and Related Equations"
        ).first()
        
        if m_good:
            print(f"Good Subtopic: Level={m_good.level}, Action={m_good.last_action}, Acc={m_good.accuracy}")
             # Should be ADVANCE because acc > 0.8 (Safety net) OR RL says so.
            if m_good.last_action == "ADVANCE":
                print("✅ Good Subtopic Verified")
            else:
                print("❌ Good Subtopic Failed (Should Advance)")
        else:
             print("❌ Good Subtopic Record Not Found")

        # Check Velocity Time Graphs (0%)
        m_bad = db.query(SubtopicMastery).filter(
            SubtopicMastery.student_id == student_id,
            SubtopicMastery.subtopic == "Velocity Time Graphs"
        ).first()
        
        if m_bad:
            print(f"Bad Subtopic: Level={m_bad.level}, Action={m_bad.last_action}, Acc={m_bad.accuracy}")
            # Should be RETRY because 0% acc and likely RL says Retry.
            if m_bad.last_action == "RETRY":
                print("✅ Bad Subtopic Verified")
            else:
                print(f"⚠️ Bad Subtopic Result: {m_bad.last_action} (RL might have been generous?)")
        else:
             print("❌ Bad Subtopic Record Not Found")

    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

if __name__ == "__main__":
    verify_rl_mastery()
