from supabase import create_client, Client
import json

SUPABASE_URL = "https://nhqmomcrcownexdpsizu.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5ocW1vbWNyY293bmV4ZHBzaXp1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk2NDk3NDUsImV4cCI6MjA4NTIyNTc0NX0.Kzce-oOtc1FrgxRhoV5iZdAqTxU7y_2IaTqiT_1kxT0"

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

results = {}

def inspect_table(table_name):
    try:
        res = supabase.table(table_name).select("*").limit(10).execute()
        results[table_name] = {
            "count": len(res.data),
            "data": res.data
        }
    except Exception as e:
        results[table_name] = {"error": str(e)}

inspect_table("textbook")
inspect_table("learning_content")
inspect_table("student_permissions")
inspect_table("subtopic_mastery")
inspect_table("students")

with open("inspect_results.json", "w") as f:
    json.dump(results, f, indent=2)
print("Results saved to inspect_results.json")
