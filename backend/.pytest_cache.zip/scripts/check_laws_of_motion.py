from app.core.database import supabase
from app.api.v1.quizzes import normalize_name, get_db_chapter

chapter = "Laws Of Motion"
normalized_input = "laws of motion"
db_chapter = get_db_chapter(normalized_input)

print(f"Checking for chapter: '{chapter}' (Resolved from '{normalized_input}' -> '{db_chapter}')")

try:
    res = supabase.table("common_test_questions").select("*").eq("chapter", db_chapter).execute()
    count = len(res.data) if res.data else 0
    print(f"Found {count} questions in 'common_test_questions'.")
    if count > 0:
        print(f"Sample: {res.data[0]}")
except Exception as e:
    print(f"Error: {e}")
