from app.core.database import supabase
import json

def inspect_table(table_name):
    print(f"\n--- Table: {table_name} ---")
    try:
        res = supabase.table(table_name).select("*").limit(1).execute()
        if res.data:
            print(f"Columns: {list(res.data[0].keys())}")
            print(f"Sample Data: {res.data[0]}")
        else:
            print("Table is empty.")
    except Exception as e:
        print(f"Error inspecting {table_name}: {e}")

inspect_table("textbook")
inspect_table("learning_content")
inspect_table("student_permissions")
inspect_table("students")
inspect_table("subtopic_mastery")
