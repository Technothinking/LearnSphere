from app.core.database import supabase
import sys

# clean output
sys.stdout.reconfigure(encoding='utf-8')

target = "Laws of Motion"
print(f"Checking if '{target}' exists in `common_test_questions` (case-insensitive)...")

try:
    # Fetch all chapters to be sure
    res = supabase.table("common_test_questions").select("chapter").execute()
    
    found = False
    if res.data:
        chapters = set(row.get('chapter', '').strip() for row in res.data)
        for c in chapters:
            if c.lower() == target.lower():
                print(f"[FOUND] Match found: '{c}'")
                found = True
        
        if not found:
            print(f"[MISSING] '{target}' NOT found in {len(chapters)} distinct chapters.")
            print("Available chapters:", sorted(list(chapters)))
    else:
        print("[EMPTY] Table is empty.")

except Exception as e:
    print(f"Error: {e}")
