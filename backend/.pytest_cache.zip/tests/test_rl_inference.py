import pytest
import numpy as np
from unittest.mock import MagicMock, patch
from rl_model.inference.decision_engine import DecisionEngine
from app.models.student import Student

@pytest.fixture
def mock_db():
    return MagicMock()

@pytest.fixture
def mock_student():
    student = Student(id="test_student", grade=10)
    student.avg_accuracy_last_5 = 0.8
    student.avg_time_per_question = 30.0
    student.current_difficulty = 1
    student.topic_mastery = 0.7
    student.attempts = 5
    student.recent_improvement = 0.05
    return student

def test_decision_engine_initialization(mock_db):
    with patch("rl_model.model.ppo_agent.load_model") as mock_load:
        # Mocking the PPO model
        mock_ppo = MagicMock()
        mock_load.return_value = mock_ppo
        
        engine = DecisionEngine(mock_db)
        assert engine.db == mock_db
        assert engine.agent is not None
        assert engine.env is not None

def test_predict_next_quiz_no_performance(mock_db, mock_student):
    with patch("rl_model.model.ppo_agent.load_model") as mock_load:
        mock_ppo = MagicMock()
        # Mock predict to return action index 2
        mock_ppo.predict.return_value = (np.array([2]), None)
        mock_load.return_value = mock_ppo
        
        engine = DecisionEngine(mock_db)
        
        # Mock map_action_to_quiz
        with patch("rl_model.data.action_mapper.map_action_to_quiz") as mock_map:
            mock_map.return_value = {"difficulty": 2, "mode": "hard"}
            
            quiz_meta = engine.predict_next_quiz(mock_student)
            
            assert quiz_meta == {"difficulty": 2, "mode": "hard"}
            mock_ppo.predict.assert_called_once()

def test_predict_next_quiz_with_performance(mock_db, mock_student):
    with patch("rl_model.model.ppo_agent.load_model") as mock_load:
        mock_ppo = MagicMock()
        mock_ppo.predict.return_value = (np.array([1]), None)
        mock_load.return_value = mock_ppo
        
        engine = DecisionEngine(mock_db)
        
        performance = {"accuracy": 0.9, "avg_time": 25.0, "topic_mastery": 0.8}
        
        # Mocking update_student_state and compute_reward
        with patch("rl_model.env.student_env.update_student_state") as mock_update, \
             patch("rl_model.env.student_env.compute_reward") as mock_reward, \
             patch("rl_model.env.student_env.build_state_vector") as mock_build, \
             patch("rl_model.env.student_env.map_action_to_quiz") as mock_map:
            
            mock_update.return_value = mock_student
            mock_reward.return_value = 0.5
            mock_build.return_value = np.zeros(6)
            mock_map.return_value = {"difficulty": 1, "mode": "medium"}
            
            quiz_meta = engine.predict_next_quiz(mock_student, performance=performance)
            
            assert quiz_meta == {"difficulty": 1, "mode": "medium"}
            mock_update.assert_called_once()
            mock_reward.assert_called_once()

if __name__ == "__main__":
    pytest.main([__file__])
