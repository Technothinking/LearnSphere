# rl_model/env/__init__.py

from .student_env import StudentEnv
from .reward import compute_reward
