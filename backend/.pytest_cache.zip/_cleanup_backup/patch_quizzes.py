import sys
import os
import re
from app.core.database import supabase
from collections import defaultdict

def patch_quizzes():
    # 1. Get Chapters and Topics from learning_content
    res = supabase.table("learning_content").select("chapter, topic").execute()
    db_structure = defaultdict(set)
    for r in res.data:
        chap = r.get('chapter')
        top = r.get('topic')
        if chap and top:
            db_structure[chap].add(top)
    
    # Format SUBTOPICS string
    subtopics_str = "SUBTOPICS = {\n"
    for chap, topics in sorted(db_structure.items()):
        topics_list = sorted(list(topics))
        subtopics_str += f"    \"{chap}\": {topics_list},\n"
    subtopics_str += "}"
    
    # 2. Get textbook chapters to check mapping
    res_tx = supabase.table("textbook").select("chapter").execute()
    tx_chapters = set([r['chapter'] for r in res_tx.data])
    
    mapping = {}
    db_chapters = set(db_structure.keys())
    for tx in tx_chapters:
        if tx not in db_chapters:
            matches = [db for db in db_chapters if db.lower() == tx.lower()]
            if matches:
                mapping[tx] = matches[0]
            # Special manual mappings if needed
            if tx == "Acids, Bases And Salts" and "Acids ,Bases And Salts" in db_chapters:
                mapping[tx] = "Acids ,Bases And Salts"
    
    mapping_str = "CHAPTER_NAME_MAP = {\n"
    for k, v in sorted(mapping.items()):
        mapping_str += f"    \"{k}\": \"{v}\",\n"
    mapping_str += "}"
    
    # 3. Read quizzes.py and replace blocks
    path = "app/api/v1/quizzes.py"
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    
    # Replace CHAPTER_NAME_MAP
    content = re.sub(r"CHAPTER_NAME_MAP = \{.*?\}", mapping_str, content, flags=re.DOTALL)
    # Replace SUBTOPICS
    content = re.sub(r"SUBTOPICS = \{.*?\}", subtopics_str, content, flags=re.DOTALL)
    
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    
    print("Successfully patched SUBTOPICS and CHAPTER_NAME_MAP in quizzes.py")

if __name__ == "__main__":
    patch_quizzes()
