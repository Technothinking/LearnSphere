import sqlite3
import json

def fix_mastery():
    conn = sqlite3.connect('sql_app.db')
    cursor = conn.cursor()
    
    # 1. Ensure 'Current Electricity' is in completed_chapters for all students who have it marked
    cursor.execute('SELECT student_id, completed_chapters FROM student_permissions')
    perms = cursor.fetchall()
    for sid, comp_json in perms:
        try:
            comp_list = json.loads(comp_json)
            if 'Current Electricity' not in comp_list:
                comp_list.append('Current Electricity')
                cursor.execute('UPDATE student_permissions SET completed_chapters = ? WHERE student_id = ?', 
                               (json.dumps(comp_list), sid))
        except:
            pass

    # 2. Fix the is_completed flag in subtopic_mastery for Current Electricity
    cursor.execute("UPDATE subtopic_mastery SET is_completed = 1 WHERE chapter = 'Current Electricity' AND subtopic IS NULL")
    
    conn.commit()
    print("Fix applied successfully.")
    conn.close()

if __name__ == "__main__":
    fix_mastery()
