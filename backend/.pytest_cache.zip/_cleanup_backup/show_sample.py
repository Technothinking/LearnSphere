from app.core.database import supabase
import json

def show_sample():
    try:
        # Fetch 1 question
        res = supabase.table("common_test_questions").select("*").limit(1).execute()
        if res.data:
            print("Sample Question Data:")
            print(json.dumps(res.data[0], indent=2))
        else:
            print("No questions found.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    show_sample()
