import sqlite3
import os

db_path = 'sql_app.db'
if os.path.exists(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Check current columns
    cursor.execute("PRAGMA table_info(subtopic_mastery)")
    columns = [row[1] for row in cursor.fetchall()]
    
    if 'accuracy' not in columns:
        print("Adding accuracy column...")
        cursor.execute('ALTER TABLE subtopic_mastery ADD COLUMN accuracy FLOAT DEFAULT 0.0')
        
    if 'level' not in columns:
        print("Adding level column...")
        cursor.execute('ALTER TABLE subtopic_mastery ADD COLUMN level INTEGER DEFAULT 0')
        
    conn.commit()
    conn.close()
    print("Migration complete!")
else:
    print(f"Database {db_path} not found.")
