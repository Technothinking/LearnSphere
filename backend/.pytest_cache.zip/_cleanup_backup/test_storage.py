from app.core.database import supabase
import os

def test_download():
    bucket_name = "Textbook"
    print(f"Listing files in '{bucket_name}'...")
    res = supabase.storage.from_(bucket_name).list()
    
    for f in res:
        name = f['name']
        print(f"File: '{name}'")
        try:
            print(f"  Attempting download of '{name}'...")
            pdf_bytes = supabase.storage.from_(bucket_name).download(name)
            print(f"  ✅ SUCCESS: Downloaded {len(pdf_bytes)} bytes.")
        except Exception as e:
            print(f"  ❌ FAILED: {name} - Error: {e}")

if __name__ == "__main__":
    test_download()
