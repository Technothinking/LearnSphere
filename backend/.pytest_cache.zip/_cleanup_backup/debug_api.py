import requests
import json

BASE_URL = "http://localhost:8000/api/v1/quizzes"

def test_api():
    try:
        # Get Subjects
        print("Fetching subjects...")
        resp = requests.get(f"{BASE_URL}/subjects")
        print(f"Status: {resp.status_code}")
        subjects = resp.json()
        print(f"Subjects: {subjects}")

        if not subjects:
            print("No subjects found. Exiting.")
            return

        # Pick first subject
        subject = subjects[0]
        print(f"\nFetching chapters for '{subject}'...")
        
        # Test Query Param
        resp = requests.get(f"{BASE_URL}/chapters", params={"subject": subject})
        print(f"Status: {resp.status_code}")
        print(f"Raw Response: {resp.text}")
        chapters = resp.json()
        print(f"Chapters: {chapters}")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_api()
