import json
from app.core.database import supabase

def seed_common_test():
    
    # Generate 30 easy questions for all main chapters
    chapters = [
        "Motion", 
        "Laws of Motion", 
        "Work and Energy", 
        "Current Electricity", 
        "Gravitation", 
        "Sound", 
        "Atoms and Molecules", 
        "Structure of the Atom",
        "Force and Laws of Motion",
        "Tissues",
        "Improvement in Food Resources"
    ]
    
    print("Seeding Common Test Questions (30 per chapter)...")
    
    try:
        for chapter in chapters:
            # Check if we already have questions
            # checking logic skipped, just inserting
            
            print(f"Generating for {chapter}...")
            
            # 1. Generate 10 MCQs
            for i in range(1, 11):
                payload = {
                    "subject": "Physics",
                    "chapter": chapter,
                    "question_type": "multiple_choice",
                    "data": {
                        "question_text": f"MCQ Q{i} for {chapter}: What corresponds to the concept?",
                        "options": ["Option A", "Option B", "Option C", "Option D"],
                        "answer": "Option A"
                    }
                }
                supabase.table("common_test_questions").insert(payload).execute()
                
            # 2. Generate 10 Fill in Blanks
            for i in range(1, 11):
                payload = {
                    "subject": "Physics",
                    "chapter": chapter,
                    "question_type": "fill_blank",
                    "data": {
                        "question_text": f"The unit of {chapter} is _______ (Fill Q{i}).",
                        "options": [],
                        "answer": "Unity"
                    }
                }
                supabase.table("common_test_questions").insert(payload).execute()
                
            # 3. Generate 10 True/False
            for i in range(1, 11):
                payload = {
                    "subject": "Physics",
                    "chapter": chapter,
                    "question_type": "true_false",
                    "data": {
                        "question_text": f"{chapter} depends on time. (T/F Q{i})",
                        "options": ["True", "False"],
                        "answer": "True"
                    }
                }
                supabase.table("common_test_questions").insert(payload).execute()
                
            print(f"  Inserted 30 mixed questions for {chapter}...")
                
        print("Seeding Common Tests Complete! 🚀")

                
        print("Seeding Common Tests Complete! 🚀")
        
    except Exception as e:
        print(f"Error seeding common tests: {e}")
        print("Did you run the SQL migration to create 'common_test_questions' table?")

if __name__ == "__main__":
    seed_common_test()
