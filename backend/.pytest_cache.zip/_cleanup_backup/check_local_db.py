from app.core.database import engine
from sqlalchemy import inspect

inspector = inspect(engine)
tables = inspector.get_table_names()
print(f"Tables: {tables}")

if "performance_history" in tables:
    columns = [c["name"] for c in inspector.get_columns("performance_history")]
    print(f"Columns in performance_history: {columns}")
else:
    print("performance_history table NOT found in local DB!")

if "subtopic_mastery" in tables:
    columns = [c["name"] for c in inspector.get_columns("subtopic_mastery")]
    print(f"Columns in subtopic_mastery: {columns}")
