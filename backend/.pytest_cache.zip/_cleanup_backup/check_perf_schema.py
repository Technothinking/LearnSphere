from app.core.database import supabase
import json

print("Checking performance_history columns...")
try:
    # Try to fetch one row to see columns
    res = supabase.table('performance_history').select('*').limit(1).execute()
    if res.data:
        print(f"Columns: {list(res.data[0].keys())}")
    else:
        print("Table is empty.")
except Exception as e:
    print(f"Error checking table: {e}")

print("\nChecking for 'topic' in some rows...")
res = supabase.table('performance_history').select('*').limit(5).execute()
for i, row in enumerate(res.data):
    print(f"Row {i}: topic={row.get('topic')}, subtopic={row.get('subtopic')}")
