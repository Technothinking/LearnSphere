import sys
import os
import numpy as np
from unittest.mock import MagicMock, patch

# Add current directory to path so imports work
sys.path.append(os.getcwd())

from rl_model.inference.decision_engine import DecisionEngine
from app.models.student import Student

def demo_rl_output():
    # 1. Setup Mock Student
    student = Student(id="demo_student", grade=10)
    student.avg_accuracy_last_5 = 0.75
    student.avg_time_per_question = 45.0
    student.current_difficulty = 1  # Medium
    student.topic_mastery = 0.6
    student.attempts = 10
    student.recent_improvement = 0.1

    print(f"--- Student State ---")
    print(f"Accuracy: {student.avg_accuracy_last_5}")
    print(f"Difficulty Level: {student.current_difficulty}")
    print(f"Mastery: {student.topic_mastery}")
    print("---------------------")

    # 2. Mock PPO Model and Environment
    # We need to patch where DecisionEngine imports PPOAgent or where PPOAgent loads the model
    # It's easier to patch 'rl_model.model.ppo_agent.load_model'
    
    with patch("rl_model.model.ppo_agent.load_model") as mock_load:
        mock_ppo = MagicMock()
        # Mocking the predict method to return a specific action (e.g., action 2 -> Hard/Quiz)
        # The logic in action_mapper determines what action 2 is.
        # Let's assume action 2 maps to specific metadata.
        mock_ppo.predict.return_value = (np.array([2]), None) 
        mock_load.return_value = mock_ppo

        # 3. Initialize Engine
        # We need a dummy DB session
        mock_db = MagicMock()
        engine = DecisionEngine(mock_db)

        # 4. Mock the action mapper to ensure we see readable output
        # (Optional: if we trust the real action mapper, we don't mock it. 
        # But real action mapper might depend on things. Let's try using the REAL one first if possible, 
        # but the test used a mock. Let's use the real one if it doesn't have complex dependencies.)
        # Looking at decision_engine.py imports: from rl_model.data.action_mapper import map_action_to_quiz
        
        # Let's let it run naturally with the mocked PPO agent returning '2'.
        
        print("\n[Running Inference...]\n")
        
        # We need to ensure 'rl_model.data.action_mapper' doesn't fail. 
        # Let's check if we need to mock it. 
        # For this demo, let's just mock it to be safe and clear about what we are showing.
        with patch("rl_model.data.action_mapper.map_action_to_quiz") as mock_map:
            expected_output = {"difficulty": 2, "mode": "hard", "focus": "adaptive"}
            mock_map.return_value = expected_output

            # 5. Get Prediction
            output = engine.predict_next_quiz(student)

            print(f"--- Model Output ---")
            print(f"Proposed Action Index: 2 (Predicted by PPO)")
            print(f"Quiz Metadata: {output}")
            print("--------------------")

if __name__ == "__main__":
    try:
        demo_rl_output()
    except Exception as e:
        print(f"Error: {e}")
