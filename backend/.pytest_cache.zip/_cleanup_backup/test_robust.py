import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold
import asyncio
import os
import time
import json
from app.services.content_service import ContentGenerationService
from app.core.database import supabase

API_KEY = "AIzaSyDlOJAlV1ADSFW1P1ect5DiFMuJoqHsLSQ"
genai.configure(api_key=API_KEY)

# Use 1.5 Pro with NO safety filters
model = genai.GenerativeModel(
    'models/gemini-1.5-pro',
    safety_settings={
        HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
    }
)

async def test_single():
    chapter = "Gravitation" # Try a common one
    filename = "Gravitation.pdf"
    subject = "Physics"
    
    print(f"--- Starting Super Robust Test for {chapter} ---")
    
    try:
        # 1. Download
        print(f"Downloading {filename}...")
        pdf_bytes = supabase.storage.from_("Textbook").download(filename)
        text = ContentGenerationService.extract_text_from_pdf(pdf_bytes)
        print(f"Extracted {len(text)} characters.")
        
        # 2. Wait to clear quota
        print("Waiting 30s for quota...")
        time.sleep(30)
        
        # 3. Generate
        prompt = f"""
        Generate 30 easy questions (10 MCQ, 10 Fill, 10 T/F) for chapter '{chapter}' based on this text:
        {text[:15000]}
        
        Output ONLY a JSON list of objects with keys: question_type, subject, chapter, data.
        """
        print("Calling Gemini 1.5 Pro...")
        response = model.generate_content(prompt)
        
        print("\n--- RESPONSE RECEIVED ---")
        res_text = response.text.strip()
        print(f"Response length: {len(res_text)}")
        
        # Clean and Parse
        if "```json" in res_text:
            res_text = res_text.split("```json")[1].split("```")[0].strip()
        elif "```" in res_text:
            res_text = res_text.split("```")[1].split("```")[0].strip()
            
        questions = json.loads(res_text)
        print(f"Successfully parsed {len(questions)} questions.")
        
        # 4. Save
        mapped = []
        for q in questions:
            mapped.append({
                "subject": subject,
                "chapter": chapter,
                "question_type": q.get("question_type", "multiple_choice"),
                "data": q.get("data")
            })
            
        supabase.table("common_test_questions").insert(mapped).execute()
        print(f"✅ SUCCESSFULLY SAVED {len(mapped)} questions to DB.")

    except Exception as e:
        print(f"❌ FAILED: {e}")
        if 'response' in locals():
            print(f"Finish Reason: {response.candidates[0].finish_reason if response.candidates else 'N/A'}")

if __name__ == "__main__":
    asyncio.run(test_single())
