import requests
import json

url = 'http://localhost:8000/api/v1/quizzes/submit/adaptive'
payload = {
    "student_id": "d16a5111-8fb7-4c22-bc4f-3ca587ed65f0",
    "email": "u@rl.com",
    "chapter": "Motion",
    "subtopic": "Distance and Displacement",
    "score": 4,
    "total_questions": 5,
    "time_taken": 120.5,
    "mastery_level": 0.8,
    "difficulty_level": 0,
    "answers": [
        {"question_id": "1", "is_correct": True, "topic": "Distance and Displacement"}
    ]
}

print(f"Submitting to {url}...")
try:
    response = requests.post(url, json=payload, timeout=10)
    print(f"Status: {response.status_code}")
    if response.status_code != 200:
        print("Raw Response Text:")
        print(response.text)
    else:
        print("Response JSON:")
        print(json.dumps(response.json(), indent=2))
except Exception as e:
    print(f"Error: {e}")
