from app.core.database import supabase
import json

# Get a sample question from common_test_questions
print("=" * 80)
print("CHECKING COMMON_TEST_QUESTIONS DATA STRUCTURE")
print("=" * 80)

res = supabase.table('common_test_questions').select('*').eq('chapter', 'Current Electricity').limit(1).execute()

if res.data and len(res.data) > 0:
    q = res.data[0]
    print(f"\nQuestion ID: {q['id']}")
    print(f"Subject: {q['subject']}")
    print(f"Chapter: {q['chapter']}")
    print(f"Question Type: {q['question_type']}")
    print(f"\nData field type: {type(q.get('data'))}")
    print(f"Data field value:")
    print(json.dumps(q.get('data'), indent=2, default=str))
    
    # Check what keys are in data
    if isinstance(q.get('data'), dict):
        print(f"\nKeys in data: {list(q['data'].keys())}")
    elif isinstance(q.get('data'), str):
        print("\nWARNING: 'data' is a string, not a dict!")
        try:
            parsed = json.loads(q['data'])
            print(f"Parsed keys: {list(parsed.keys())}")
        except:
            print("Failed to parse as JSON")
else:
    print("No questions found for 'Current Electricity'")
    print("\nTrying 'Laws of Motion'...")
    res = supabase.table('common_test_questions').select('*').eq('chapter', 'Laws of Motion').limit(1).execute()
    if res.data:
        q = res.data[0]
        print(json.dumps(q.get('data'), indent=2, default=str))
