from app.core.database import engine
from sqlalchemy import inspect

inspector = inspect(engine)
if "student_permissions" in inspector.get_table_names():
    cols = [c['name'] for c in inspector.get_columns('student_permissions')]
    print(f"student_permissions columns: {cols}")
else:
    print("student_permissions table NOT found!")
