from app.core.database import supabase

res = supabase.table('common_test_questions').select('subject, chapter').execute()
chapters = {}
for item in res.data:
    subj = item['subject']
    chap = item['chapter']
    if subj not in chapters:
        chapters[subj] = set()
    chapters[subj].add(chap)

print("CHAPTERS IN common_test_questions:")
for subj in sorted(chapters.keys()):
    print(f"\n{subj}:")
    for chap in sorted(chapters[subj]):
        print(f"  - {chap}")
