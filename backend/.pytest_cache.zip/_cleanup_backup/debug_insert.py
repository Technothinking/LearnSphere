from app.core.database import supabase
import json

def debug_insert():
    print("Testing insertion into common_test_questions...")
    test_data = {
        "subject": "Test Physics",
        "chapter": "Test Motion",
        "question_type": "multiple_choice",
        "data": {
            "question_text": "Is this a test?",
            "options": ["Yes", "No"],
            "answer": "Yes"
        }
    }
    
    try:
        res = supabase.table("common_test_questions").insert(test_data).execute()
        print("Success! Data inserted.")
        print("Response:", res.data)
    except Exception as e:
        print("\n--- INSERTION FAILED ---")
        print("Error Type:", type(e))
        print("Error Message:", str(e))
        
        # Check if it's a column issue
        if "column" in str(e).lower() and "does not exist" in str(e).lower():
            print("\nSUGGESTION: The 'question_type' column might be missing. Did you run the SQL migration?")
        elif "policy" in str(e).lower() or "permission" in str(e).lower():
            print("\nSUGGESTION: Row Level Security (RLS) might be blocking anonymous inserts.")
        elif "relation" in str(e).lower() and "does not exist" in str(e).lower():
            print("\nSUGGESTION: The 'common_test_questions' table itself might be missing.")

if __name__ == "__main__":
    debug_insert()
