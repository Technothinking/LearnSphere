from app.core.database import supabase

print("Current textbook entries:")
tb = supabase.table('textbook').select('subject, chapter').execute()
for i in tb.data:
    print(f"  {i['subject']} | {i['chapter']}")

print("\nUpdating 'Motion' to 'Laws of Motion'...")
res = supabase.table('textbook').update({'chapter': 'Laws of Motion'}).eq('chapter', 'Motion').execute()
print(f"Updated {len(res.data)} rows")

print("\nNew textbook entries:")
tb2 = supabase.table('textbook').select('subject, chapter').execute()
for i in tb2.data:
    print(f"  {i['subject']} | {i['chapter']}")
