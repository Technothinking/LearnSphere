from app.core.database import supabase
import requests

print("=" * 60)
print("1. CHECKING TEXTBOOK TABLE")
print("=" * 60)
tb = supabase.table('textbook').select('subject, chapter').execute()
for i in tb.data:
    print(f"  {i['subject']:15} | {i['chapter']}")

print("\n" + "=" * 60)
print("2. CHECKING COMMON_TEST_QUESTIONS TABLE")
print("=" * 60)
res = supabase.table('common_test_questions').select('subject, chapter, id').execute()
chapters_dict = {}
for item in res.data:
    key = f"{item['subject']} | {item['chapter']}"
    if key not in chapters_dict:
        chapters_dict[key] = 0
    chapters_dict[key] += 1

for key, count in sorted(chapters_dict.items()):
    print(f"  {key:50} - {count} questions")

print("\n" + "=" * 60)
print("3. TESTING API ENDPOINT WITH 'Motion'")
print("=" * 60)
try:
    response = requests.get('http://localhost:8000/api/v1/quizzes/common-test?chapter=Motion&subject=Physics&limit=5')
    print(f"Status code: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print(f"Questions returned: {len(data)}")
        if data:
            print(f"First question type: {data[0].get('question_type')}")
    else:
        print(f"Error: {response.text}")
except Exception as e:
    print(f"API Error: {e}")

print("\n" + "=" * 60)
print("4. TESTING DIRECT DB QUERY FOR 'Laws of Motion'")
print("=" * 60)
direct_res = supabase.table('common_test_questions').select('*').eq('chapter', 'Laws of Motion').limit(3).execute()
print(f"Found {len(direct_res.data)} questions for 'Laws of Motion'")
if direct_res.data:
    print(f"Sample question ID: {direct_res.data[0]['id']}")
    print(f"Question type: {direct_res.data[0]['question_type']}")
