from app.core.database import supabase

def get_mapping():
    # 1. Get Chapters from textbook (UI Names)
    res_ui = supabase.table("textbook").select("chapter").execute()
    ui_chapters = sorted(list(set([r['chapter'] for r in res_ui.data])))
    
    # 2. Get Chapters from learning_content (DB Names)
    res_db = supabase.table("learning_content").select("chapter").execute()
    db_chapters = sorted(list(set([r['chapter'] for r in res_db.data])))
    
    print("UI Chapters (textbook):")
    for c in ui_chapters:
        print(f"  - {c}")
        
    print("\nDB Chapters (learning_content):")
    for c in db_chapters:
        print(f"  - {c}")

if __name__ == "__main__":
    get_mapping()
