import requests
import json

BASE_URL = "http://localhost:8000/api/v1"
STUDENT_ID = "d16a5111-8fb7-4c22-bc4f-3ca587ed65f0"
CHAPTER = "Motion"

def test_progression():
    print(f"--- Testing Progression for {STUDENT_ID} in {CHAPTER} ---")
    
    # 1. Take Common Test
    print("\n1. Submitting Common Test (passed)...")
    payload = {
        "student_id": STUDENT_ID,
        "chapter": CHAPTER,
        "score": 18,
        "total_questions": 20,
        "time_taken": 300,
        "difficulty_level": 1,
        "answers": [] # Empty for simplicity
    }
    res = requests.post(f"{BASE_URL}/quizzes/submit/adaptive", json=payload)
    try:
        data = res.json()
        print("Response:", data.get('message'))
    except:
        print("Response Error:", res.status_code)
        print(res.text)
        return
    
    # 2. Check Mastery Level
    print("\n2. Checking Mastery...")
    res = requests.get(f"{BASE_URL}/quizzes/mastery/{STUDENT_ID}")
    mastery = res.json()
    print("Mastery Chapters:", list(mastery.keys()))
    print("Mastery Data for CHAPTER:", json.dumps(mastery.get(CHAPTER), indent=2))
    
    # 3. Take Subtopic Test (Level 0 -> 1)
    topics = list(mastery.get(CHAPTER, {}).keys())
    if topics:
        topic = topics[0]
        if topic == "CHAPTER_COMPLETE": topic = topics[1] if len(topics) > 1 else None
        
        if topic:
            print(f"\n3. Submitting {topic} Test (Score 100%, should Level Up from 0 to 1)...")
            payload["subtopic"] = topic
            payload["score"] = 10
            payload["total_questions"] = 10
            res = requests.post(f"{BASE_URL}/quizzes/submit/adaptive", json=payload)
            print("Response:", res.json().get('message'))
            
            # 4. Check Level again
            res = requests.get(f"{BASE_URL}/quizzes/mastery/{STUDENT_ID}")
            print(f"Updated Level for {topic}:", res.json().get(CHAPTER, {}).get(topic, {}).get('level'))

if __name__ == "__main__":
    test_progression()
