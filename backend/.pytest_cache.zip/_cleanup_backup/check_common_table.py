from app.core.database import supabase
import sys

try:
    print("Checking for common_test_questions table...")
    res = supabase.table("common_test_questions").select("*").limit(1).execute()
    print("Result Data:", res.data)
    print("Table Exists!")
except Exception as e:
    print("Error:", e)
    # Check for specific error code if possible, but printing is enough
    if "relation" in str(e) and "does not exist" in str(e):
        print("TABLE_MISSING")
    else:
        print("OTHER_ERROR")
