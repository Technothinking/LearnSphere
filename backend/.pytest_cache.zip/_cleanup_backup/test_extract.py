from app.services.content_service import ContentGenerationService
from app.core.database import supabase
import os

def test_extract():
    bucket_name = "Textbook"
    filename = "Motion.pdf"
    
    try:
        print(f"Downloading {filename}...")
        pdf_bytes = supabase.storage.from_(bucket_name).download(filename)
        text = ContentGenerationService.extract_text_from_pdf(pdf_bytes)
        print(f"Extracted {len(text)} characters.")
        print("First 200 chars:", text[:200])
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_extract()
