from app.core.database import supabase
from collections import defaultdict

def extract_structure():
    # 1. Get from learning_content
    res = supabase.table("learning_content").select("chapter, topic").execute()
    db_structure = defaultdict(set)
    for r in res.data:
        chap = r.get('chapter')
        top = r.get('topic')
        if chap and top:
            db_structure[chap].add(top)
            
    print("SUBTOPICS = {")
    for chap, topics in sorted(db_structure.items()):
        topics_list = sorted(list(topics))
        print(f"    \"{chap}\": {topics_list},")
    print("}")
    
    # 2. Get from textbook for mapping
    res_tx = supabase.table("textbook").select("chapter").execute()
    tx_chapters = set([r['chapter'] for r in res_tx.data])
    
    print("\n# Potential Mapping Needed (Textbook vs DB):")
    db_chapters = set(db_structure.keys())
    for tx in sorted(tx_chapters):
        if tx not in db_chapters:
            # Try fuzzy match or casing
            matches = [db for db in db_chapters if db.lower() == tx.lower()]
            if matches:
                print(f"    \"{tx}\": \"{matches[0]}\",")
            else:
                print(f"    \"{tx}\": \"MISSING IN DB\",")

if __name__ == "__main__":
    extract_structure()
