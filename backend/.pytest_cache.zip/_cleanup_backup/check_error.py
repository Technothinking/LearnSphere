import google.generativeai as genai
import traceback

API_KEY = "AIzaSyDlOJAlV1ADSFW1P1ect5DiFMuJoqHsLSQ"
genai.configure(api_key=API_KEY)

def check_error():
    try:
        model = genai.GenerativeModel('gemini-1.5-flash')
        response = model.generate_content("Hello")
        print("Success:", response.text)
    except Exception as e:
        print("--- ERROR DETAILED ---")
        print(f"Type: {type(e)}")
        print(f"Message: {e}")
        # traceback.print_exc()

if __name__ == "__main__":
    check_error()
