from app.core.database import supabase

print("=== TEXTBOOK TABLE ===")
tb = supabase.table('textbook').select('subject, chapter').execute()
for i in tb.data:
    print(f"{i['subject']:15} | {i['chapter']}")

print("\n=== COMMON_TEST_QUESTIONS TABLE ===")
ct = supabase.table('common_test_questions').select('subject, chapter').execute()
seen = set()
for i in ct.data:
    key = (i['subject'], i['chapter'])
    if key not in seen:
        print(f"{i['subject']:15} | {i['chapter']}")
        seen.add(key)

print("\n=== LEARNING_CONTENT TABLE ===")
lc = supabase.table('learning_content').select('subject, chapter').execute()
seen2 = set()
for i in lc.data:
    key = (i['subject'], i['chapter'])
    if key not in seen2:
        print(f"{i['subject']:15} | {i['chapter']}")
        seen2.add(key)
