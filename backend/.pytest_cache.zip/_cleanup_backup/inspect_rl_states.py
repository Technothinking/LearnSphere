from app.core.database import supabase

def inspect_rl_states():
    try:
        print("Fetching one row from rl_states...")
        response = supabase.table("rl_states").select("*").limit(1).execute()
        if response.data:
            print(f"Columns: {response.data[0].keys()}")
        else:
            print("Table exists but is empty. Cannot determine columns easily without metadata API (which isn't standard here).")
            # Try inserting a dummy with known fields to see if it errs, or just rely on what we want to use.
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    inspect_rl_states()
