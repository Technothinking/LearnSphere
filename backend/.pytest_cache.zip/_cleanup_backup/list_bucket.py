from app.core.database import supabase

def list_bucket_files():
    try:
        bucket_name = "Textbook"
        print(f"Listing files in bucket '{bucket_name}'...")
        res = supabase.storage.from_(bucket_name).list()
        
        if not res:
            print("Bucket is empty or error accessing it.")
            return

        print(f"Found {len(res)} files:")
        for f in res:
            print(f" - {f.get('name')} (Size: {f.get('metadata', {}).get('size', 'N/A')})")
            
    except Exception as e:
        print(f"Error listing bucket: {e}")

if __name__ == "__main__":
    list_bucket_files()
