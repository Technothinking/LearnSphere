import requests
import json

url = 'http://localhost:8000/api/v1/quizzes/common-test?chapter=Current Electricity&subject=Science&limit=1'
response = requests.get(url)

print(f"Status: {response.status_code}")
print("\nResponse JSON:")
data = response.json()
print(json.dumps(data, indent=2, default=str))

if data and len(data) > 0:
    print("\n" + "=" * 60)
    print("First question 'data' field:")
    print(json.dumps(data[0].get('data'), indent=2, default=str))
    print("\nType of 'data' field:", type(data[0].get('data')))
