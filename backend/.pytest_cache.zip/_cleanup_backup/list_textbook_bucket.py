from app.core.database import supabase

def list_bucket():
    bucket_name = "Textbook"
    print(f"Listing files in bucket '{bucket_name}'...")
    try:
        res = supabase.storage.from_(bucket_name).list()
        if not res:
            print("No files found.")
            return
        
        for f in res:
            name = f.get('name')
            file_id = f.get('id')
            print(f"File: '{name}' | ID: {file_id}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    list_bucket()
