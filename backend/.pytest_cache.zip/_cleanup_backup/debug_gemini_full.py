import google.generativeai as genai
import traceback
import os
import asyncio
from app.services.content_service import ContentGenerationService
from app.core.database import supabase

API_KEY = "AIzaSyDlOJAlV1ADSFW1P1ect5DiFMuJoqHsLSQ"
genai.configure(api_key=API_KEY)
model = genai.GenerativeModel('models/gemini-1.5-pro')

async def debug_full():
    chapter = "Motion"
    print(f"--- Debugging Gemini for chapter: {chapter} ---")
    
    try:
        # 1. Get Text
        print("Downloading Motion.pdf...")
        pdf_bytes = supabase.storage.from_("Textbook").download("Motion.pdf")
        text = ContentGenerationService.extract_text_from_pdf(pdf_bytes)
        print(f"Extracted {len(text)} characters.")
        
        # 2. Call Gemini
        prompt = f"Generate 5 easy MCQs for {chapter} based on: {text[:5000]}. Return ONLY JSON."
        print("Calling Gemini...")
        response = model.generate_content(prompt)
        
        print("\n--- RESPONSE ATTRIBUTES ---")
        try:
            print(f"Text available: {True if response.text else False}")
            print(f"Text content: {response.text}")
        except Exception as e:
            print(f"Could not get response.text: {e}")
            print(f"Prompt feedback: {response.prompt_feedback}")
            print(f"Candidates: {response.candidates}")

    except Exception as e:
        print("\n--- EXCEPTION CAUGHT ---")
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(debug_full())
