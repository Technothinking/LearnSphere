import requests

def trigger_bulk_gen():
    url = "http://localhost:8000/api/v1/content/generate-bulk"
    params = {
        "bucket_name": "Textbook",
        "subject": "Physics"
    }
    
    try:
        print(f"Triggering Bulk Generation at {url}...")
        response = requests.post(url, params=params)
        print("Status Code:", response.status_code)
        print("Response:", response.json())
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    trigger_bulk_gen()
