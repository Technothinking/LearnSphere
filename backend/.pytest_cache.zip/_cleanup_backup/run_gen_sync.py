import asyncio
import os
from app.services.content_service import ContentGenerationService
from app.core.database import supabase

# Mocking background tasks/DB session not needed since service uses supabase directly

async def run_sync_gen():
    print("Starting Synchronous Generation for All PDFs...")
    bucket_name = "Textbook"
    subject = "Physics"
    
    # List files
    files = supabase.storage.from_(bucket_name).list()
    if not files:
        print("No files found in bucket.")
        return

    import time

    for f in files:
        fname = f.get('name')
        if not fname.lower().endswith('.pdf'):
            continue
            
        chapter_name = os.path.splitext(fname)[0].replace('_', ' ').title()
        print(f"\nProcessing: {fname} (Chapter: {chapter_name})")
        
        # Check if already exists
        try:
             # Fast check: see if we have > 0 questions for this chapter
             res = supabase.table("common_test_questions").select("id", count="exact").eq("chapter", chapter_name).limit(1).execute()
             if res.count and res.count >= 30:
                 print(f"Skipping {chapter_name} - Already has {res.count} questions.")
                 continue
        except Exception as e:
            print(f"Check failed: {e}")

        retry_count = 0
        max_retries = 3
        
        while retry_count < max_retries:
            try:
                # Call the service directly
                result = await ContentGenerationService.process_textbook_pdf(
                    bucket_name=bucket_name,
                    filename=fname,
                    subject=subject,
                    chapter_name=chapter_name
                )
                print(f"Result: {result}")
                
                # Check for rate limit error in result if it returned a dict with error
                if isinstance(result, dict) and 'error' in result and '429' in str(result['error']):
                     raise Exception("Rate limit hit in service response")
                     
                break # Success
            except Exception as e:
                print(f"Error processing {fname}: {e}")
                if "429" in str(e) or "quota" in str(e).lower():
                    print("Rate limit hit. Waiting 20 seconds...")
                    time.sleep(20)
                    retry_count += 1
                else:
                    break # Other error, don't retry
        
        print("Waiting 5s before next...")
        time.sleep(5)

if __name__ == "__main__":
    asyncio.run(run_sync_gen())
