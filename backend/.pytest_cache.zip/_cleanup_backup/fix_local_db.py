from app.core.database import engine
from sqlalchemy import inspect, text

def add_column(table_name, column_name, column_type):
    inspector = inspect(engine)
    columns = [c['name'] for c in inspector.get_columns(table_name)]
    if column_name not in columns:
        print(f"Adding column {column_name} to table {table_name}...")
        with engine.connect() as conn:
            conn.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}"))
            conn.commit()
    else:
        print(f"Column {column_name} already exists in table {table_name}.")

# 1. Student Permissions
add_column("student_permissions", "completed_chapters", "TEXT DEFAULT '[]'")

# 2. Performance History
add_column("performance_history", "subtopic", "TEXT")
add_column("performance_history", "topic", "TEXT") # For compatibility

# 3. Students (Check RL fields)
student_fields = [
    ("avg_accuracy_last_5", "FLOAT DEFAULT 0.0"),
    ("avg_time_per_question", "FLOAT DEFAULT 0.0"),
    ("current_difficulty", "INTEGER DEFAULT 0"),
    ("topic_mastery", "FLOAT DEFAULT 0.0"),
    ("attempts", "INTEGER DEFAULT 0"),
    ("recent_improvement", "FLOAT DEFAULT 0.0")
]

for field, ftype in student_fields:
    add_column("students", field, ftype)

print("Local Database Migration Complete!")
