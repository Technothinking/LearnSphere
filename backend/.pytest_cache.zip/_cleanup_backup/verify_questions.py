from app.core.database import supabase

print("Checking common_test_questions for 'Laws Of Motion'...")
res = supabase.table('common_test_questions').select('*').eq('chapter', 'Laws Of Motion').execute()
print(f"Found {len(res.data)} questions")

if res.data:
    print("\nFirst question:")
    print(res.data[0])
else:
    print("\nNo questions found! Checking what chapters exist...")
    all_res = supabase.table('common_test_questions').select('subject, chapter').execute()
    seen = set()
    for item in all_res.data:
        key = (item['subject'], item['chapter'])
        if key not in seen:
            print(f"  {item['subject']} | {item['chapter']}")
            seen.add(key)
