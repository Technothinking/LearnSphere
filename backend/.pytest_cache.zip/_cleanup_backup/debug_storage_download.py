from app.core.database import supabase
import urllib.parse

def debug_downloads():
    bucket_name = "Textbook"
    print(f"Listing files in bucket '{bucket_name}'...")
    try:
        res = supabase.storage.from_(bucket_name).list()
        if not res:
            print("No files found.")
            return
        
        for f in res:
            name = f.get('name')
            if not name: continue
            
            print(f"\n--- Testing: '{name}' ---")
            try:
                # Try standard download
                print(f"  Attempting standard download...")
                data = supabase.storage.from_(bucket_name).download(name)
                print(f"  ✅ Success! Downloaded {len(data)} bytes.")
            except Exception as e:
                print(f"  ❌ Standard failed: {e}")
                
            try:
                # Try URL encoded name
                encoded_name = urllib.parse.quote(name)
                print(f"  Attempting encoded download ('{encoded_name}')...")
                data = supabase.storage.from_(bucket_name).download(encoded_name)
                print(f"  ✅ Encoded Success! Downloaded {len(data)} bytes.")
            except Exception as e:
                print(f"  ❌ Encoded failed: {e}")

    except Exception as e:
        print(f"Overall Error: {e}")

if __name__ == "__main__":
    debug_downloads()
