from app.core.database import SessionLocal, supabase
from app.api.v1.quizzes import submit_adaptive_test
from app.schemas.quiz_schema import AdaptiveTestSubmission

db = SessionLocal()
try:
    payload = {
        "student_id": "d16a5111-8fb7-4c22-bc4f-3ca587ed65f0",
        "email": "u@rl.com",
        "chapter": "Motion",
        "subtopic": "Distance and Displacement",
        "score": 4,
        "total_questions": 5,
        "time_taken": 120.5,
        "mastery_level": 0.8,
        "difficulty_level": 0,
        "answers": [
            {"question_id": 1, "is_correct": True, "topic": "Distance and Displacement"}
        ]
    }
    submission = AdaptiveTestSubmission(**payload)
    print("Executing submit_adaptive_test...")
    result = submit_adaptive_test(submission, db)
    print("Success!")
    print(result)
except Exception as e:
    import traceback
    traceback.print_exc()
finally:
    db.close()
