from app.core.database import supabase

print("Adding 'topic' and 'subtopic' columns to performance_history...")
try:
    # Supabase Python client doesn't support direct ALTER TABLE easily via the table() interface.
    # Usually you'd use the SQL editor. But we can try to use a RPC if available, 
    # or just warn the user.
    # Actually, let's use the 'execute' with a raw SQL if possible? No.
    
    print("Please run the following SQL in your Supabase SQL Editor:")
    print("-" * 40)
    print("ALTER TABLE performance_history ADD COLUMN IF NOT EXISTS topic TEXT;")
    print("ALTER TABLE performance_history ADD COLUMN IF NOT EXISTS subtopic TEXT;")
    print("-" * 40)
    
    print("\nAttempting to verify columns again...")
    res = supabase.table('performance_history').select('*').limit(1).execute()
    if res.data:
        print(f"Current Columns: {list(res.data[0].keys())}")
    else:
        print("Table is empty, cannot verify columns without a row.")
except Exception as e:
    print(f"Error: {e}")
