from app.core.database import supabase
import json

try:
    response = supabase.table("learning_content").select("*").limit(1).execute()
    if response.data:
        print(json.dumps(response.data[0], indent=2))
    else:
        print("No data found in learning_content")
except Exception as e:
    print(f"Error: {e}")
