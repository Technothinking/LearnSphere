from app.core.database import engine
from sqlalchemy import inspect

inspector = inspect(engine)
cols = [c['name'] for c in inspector.get_columns('students')]
print(f"students columns: {cols}")
