import json
from app.core.database import supabase

questions = [
    {
        "question_type": "multiple_choice",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Introduction",
        "data": {
            "question_text": "Who made the first telescope for space observation?",
            "options": ["A) Newton", "B) Galileo Galilei", "C) Einstein", "D) Copernicus"],
            "answer": "B"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Introduction",
        "data": {
            "question_text": "Early sky watching helped humans in __________.",
            "answer": "agriculture"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Introduction",
        "data": {
            "question_text": "Constellations helped sailors for navigation. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Forms of Light",
        "data": {
            "question_text": "Light is a type of ______ wave.",
            "options": ["A) Mechanical", "B) Electromagnetic", "C) Sound", "D) Water"],
            "answer": "B"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Forms of Light",
        "data": {
            "question_text": "Visible light has wavelengths between _____ nm and _____ nm.",
            "answer": "400,800"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Forms of Light",
        "data": {
            "question_text": "Human eyes can see infrared radiation. True or False?",
            "answer": "False"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Forms of Light",
        "data": {
            "question_text": "Which radiation has the shortest wavelength?",
            "options": ["A) Radio", "B) Infrared", "C) Gamma", "D) Visible"],
            "answer": "C"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Forms of Light",
        "data": {
            "question_text": "1 pm equals _____ meters.",
            "answer": "10^-12"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Forms of Light",
        "data": {
            "question_text": "Radio waves have the longest wavelength. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Optical Telescopes",
        "data": {
            "question_text": "Optical telescopes observe mainly which radiation?",
            "options": ["A) X-rays", "B) Gamma rays", "C) Visible light", "D) Radio waves"],
            "answer": "C"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Optical Telescopes",
        "data": {
            "question_text": "Telescopes using lenses are called __________ telescopes.",
            "answer": "refracting"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Optical Telescopes",
        "data": {
            "question_text": "Light bending in a lens is called refraction. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Optical Telescopes",
        "data": {
            "question_text": "Which part collects most of the light?",
            "options": ["A) Eyepiece", "B) Objective lens", "C) Mirror", "D) Filter"],
            "answer": "B"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Optical Telescopes",
        "data": {
            "question_text": "Colour errors in lenses are called __________ aberration.",
            "answer": "chromatic"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Optical Telescopes",
        "data": {
            "question_text": "Large lenses are easy to manufacture. True or False?",
            "answer": "False"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Reflecting Telescopes",
        "data": {
            "question_text": "Reflecting telescopes use which device?",
            "options": ["A) Lens", "B) Prism", "C) Concave mirror", "D) Filter"],
            "answer": "C"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Reflecting Telescopes",
        "data": {
            "question_text": "Reflecting telescopes work on the principle of __________.",
            "answer": "reflection"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Reflecting Telescopes",
        "data": {
            "question_text": "Mirrors do not suffer from chromatic aberration. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Types",
        "data": {
            "question_text": "Which is a reflecting telescope type?",
            "options": ["A) Newtonian", "B) Refracting", "C) Infrared", "D) Gamma"],
            "answer": "A"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Types",
        "data": {
            "question_text": "The Newtonian telescope uses a __________ mirror as secondary mirror.",
            "answer": "plane"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Types",
        "data": {
            "question_text": "Cassegrain telescope uses a convex mirror. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Radio Telescopes",
        "data": {
            "question_text": "Radio telescopes detect which waves?",
            "options": ["A) Radio", "B) Visible", "C) X-rays", "D) UV"],
            "answer": "A"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Radio Telescopes",
        "data": {
            "question_text": "Radio telescope dishes are usually __________ shaped.",
            "answer": "parabolic"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Radio Telescopes",
        "data": {
            "question_text": "Radio waves cannot be detected using special receivers. True or False?",
            "answer": "False"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "GMRT",
        "data": {
            "question_text": "GMRT is located near which city?",
            "options": ["A) Mumbai", "B) Delhi", "C) Pune", "D) Chennai"],
            "answer": "C"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "GMRT",
        "data": {
            "question_text": "GMRT has _____ dishes.",
            "answer": "30"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "GMRT",
        "data": {
            "question_text": "Each GMRT dish is 45 m in diameter. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "GMRT",
        "data": {
            "question_text": "GMRT arrangement works like a single dish of about ______ diameter.",
            "options": ["A) 5 km", "B) 10 km", "C) 25 km", "D) 50 km"],
            "answer": "C"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Space Telescopes",
        "data": {
            "question_text": "Hubble telescope was launched in _____.",
            "answer": "1990"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Space Telescopes",
        "data": {
            "question_text": "Hubble orbits above Earth’s atmosphere. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Space Telescopes",
        "data": {
            "question_text": "Hubble mainly observes which radiation?",
            "options": ["A) Visible", "B) Radio", "C) Gamma", "D) Infrared only"],
            "answer": "A"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Space Telescopes",
        "data": {
            "question_text": "Hubble orbits at about _____ km height.",
            "answer": "589"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Space Telescopes",
        "data": {
            "question_text": "Space telescopes give clearer images than ground telescopes. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Chandra",
        "data": {
            "question_text": "Chandra telescope studies which radiation?",
            "options": ["A) Visible", "B) Infrared", "C) X-rays", "D) Radio"],
            "answer": "C"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Chandra",
        "data": {
            "question_text": "Chandra is named after scientist __________ Chandrashekhar.",
            "answer": "Subramanian"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Chandra",
        "data": {
            "question_text": "X-ray telescopes are easily operated on Earth’s surface. True or False?",
            "answer": "False"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Atmosphere",
        "data": {
            "question_text": "Which reduces intensity of light reaching Earth?",
            "options": ["A) Rotation", "B) Atmosphere", "C) Gravity", "D) Magnetism"],
            "answer": "B"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Atmosphere",
        "data": {
            "question_text": "Atmospheric turbulence causes __________ of images.",
            "answer": "shaking"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Atmosphere",
        "data": {
            "question_text": "City lights affect astronomical observations. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Atmosphere",
        "data": {
            "question_text": "Optical telescopes are placed on mountains to avoid ______.",
            "options": ["A) Rain", "B) Clouds", "C) Atmospheric disturbance", "D) Gravity"],
            "answer": "C"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "ISRO",
        "data": {
            "question_text": "ISRO was established in _____.",
            "answer": "1969"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "ISRO",
        "data": {
            "question_text": "ISRO headquarters is in Bengaluru. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "ISRO",
        "data": {
            "question_text": "ISRO is responsible for launching ______.",
            "options": ["A) Cars", "B) Satellites", "C) Ships", "D) Submarines"],
            "answer": "B"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Satellites",
        "data": {
            "question_text": "INSAT supports __________ services.",
            "answer": "telecommunication"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Satellites",
        "data": {
            "question_text": "EDUSAT is used only for education. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Satellites",
        "data": {
            "question_text": "IRS satellites are used for ______ management.",
            "options": ["A) Water", "B) Resource", "C) Money", "D) Energy"],
            "answer": "B"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Satellites",
        "data": {
            "question_text": "Astrosat was launched in _____.",
            "answer": "2015"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Astrosat",
        "data": {
            "question_text": "Astrosat has ultraviolet and X-ray telescopes. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Astrosat",
        "data": {
            "question_text": "Astrosat is unique because it carries ______.",
            "options": ["A) One telescope", "B) Multiple types of telescopes", "C) Only radio dish", "D) Only cameras"],
            "answer": "B"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Concepts",
        "data": {
            "question_text": "A telescope used to receive radio waves is called a __________ telescope.",
            "answer": "radio"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Concepts",
        "data": {
            "question_text": "All heavenly bodies emit only visible light. True or False?",
            "answer": "False"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Concepts",
        "data": {
            "question_text": "Which radiation cannot pass easily through Earth’s atmosphere?",
            "options": ["A) Visible", "B) Radio", "C) X-rays", "D) Infrared"],
            "answer": "C"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Concepts",
        "data": {
            "question_text": "Mirrors form images without __________ aberration.",
            "answer": "chromatic"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Concepts",
        "data": {
            "question_text": "Bigger mirrors collect more light. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "medium",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Concepts",
        "data": {
            "question_text": "Which telescope uses both concave and convex mirrors?",
            "options": ["A) Newtonian", "B) Cassegrain", "C) Refracting", "D) Radio"],
            "answer": "B"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Concepts",
        "data": {
            "question_text": "Telescopes placed in space avoid problems caused by Earth’s __________.",
            "answer": "atmosphere"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Concepts",
        "data": {
            "question_text": "Radio telescopes use parabolic dishes. True or False?",
            "answer": "True"
        }
    },
    {
        "question_type": "multiple_choice",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Concepts",
        "data": {
            "question_text": "Which mirror is used in Newtonian telescope?",
            "options": ["A) Convex", "B) Plane", "C) Parabolic", "D) Prism"],
            "answer": "B"
        }
    },
    {
        "question_type": "fill_blank",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Concepts",
        "data": {
            "question_text": "Space telescopes give brighter and more __________ images.",
            "answer": "clear"
        }
    },
    {
        "question_type": "true_false",
        "difficulty": "easy",
        "subject": "Science",
        "chapter": "Observing Space Telescopes",
        "topic": "Concepts",
        "data": {
            "question_text": "Astronomy uses only one type of telescope. True or False?",
            "answer": "False"
        }
    }
]

print(f"Total questions to insert: {len(questions)}")

try:
    for i in range(0, len(questions), 10):
        batch = questions[i:i+10]
        supabase.table("learning_content").insert(batch).execute()
        print(f"Inserted batch {i//10 + 1}")
    print("Insertion complete!")
except Exception as e:
    print(f"Error during insertion: {e}")
