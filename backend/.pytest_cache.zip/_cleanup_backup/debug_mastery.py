import sqlite3
import json

def check_mastery():
    conn = sqlite3.connect('sql_app.db')
    cursor = conn.cursor()
    
    # Check permissions
    cursor.execute('SELECT student_id, completed_chapters FROM student_permissions')
    perms = cursor.fetchall()
    print("--- Permissions ---")
    for p in perms:
        print(f"Student: {p[0]}")
        print(f"Completed Chapters: {p[1]}")
        
    # Check mastery records for Current Electricity
    print("\n--- Mastery Records for 'Current Electricity' ---")
    cursor.execute("SELECT id, subtopic, is_completed, level, accuracy FROM subtopic_mastery WHERE chapter = 'Current Electricity'")
    records = cursor.fetchall()
    for r in records:
        print(f"ID: {r[0]}, Subtopic: {r[1]}, Completed: {r[2]}, Level: {r[3]}, Accuracy: {r[4]}")

    conn.close()

if __name__ == "__main__":
    check_mastery()
