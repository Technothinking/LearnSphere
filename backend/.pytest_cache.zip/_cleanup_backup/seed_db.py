import json
from app.core.database import supabase

def seed_content():
    json_path = "DAtabase_architecture/questions_20260129_102320.json"
    
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            questions = json.load(f)
            
        print(f"Loading {len(questions)} questions...")
        
        for q in questions:
            content_data = {
                "subject": "Science", # Assumed subject
                "chapter": q.get("chapter", "General"),
                "topic": q.get("chapter", "General"),
                "difficulty": "medium", # Default
                "content_type": "quiz",
                "data": {
                    "question_text": q.get("question_text"),
                    "options": q.get("options", []),
                    "answer": q.get("correct_answer")
                }
            }
            
            res = supabase.table("learning_content").insert(content_data).execute()
            print(f"Inserted: {q.get('question_text')[:50]}...")
            
        print("Seeding complete! 🚀")
        
    except Exception as e:
        print(f"Error seeding content: {e}")

if __name__ == "__main__":
    seed_content()
