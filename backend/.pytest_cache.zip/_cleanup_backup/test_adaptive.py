"""
Backend Test Script for Adaptive Test Flow

This script tests the /submit/adaptive endpoint with two scenarios:
1. ADVANCE: High score (>= 70% accuracy)
2. RETRY: Low score (< 70% accuracy) with per-topic analysis

Prerequisites:
- Backend must be running: uvicorn app.main:app --reload
- Update BASE_URL if using different host/port

Usage:
    python test_adaptive.py
"""

import requests
import json

BASE_URL = "http://localhost:8000/api/v1"

def test_advance():
    """Test ADVANCE scenario: Student scores >= 70%"""
    print("\n" + "="*60)
    print("TEST 1: ADVANCE SCENARIO (High Score)")
    print("="*60)
    
    payload = {
        "student_id": "test-student-advance",
        "chapter": "Matter in Our Surroundings",
        "score": 5,
        "total_questions": 5,
        "time_taken": 120,  # 2 minutes for 5 questions (24s per question - good speed)
        "mastery_level": 0.9,
        "difficulty_level": 1,
        "answers": [
            {"question_id": "q1", "is_correct": True},
            {"question_id": "q2", "is_correct": True},
            {"question_id": "q3", "is_correct": True},
            {"question_id": "q4", "is_correct": True},
            {"question_id": "q5", "is_correct": True},
        ]
    }
    
    print(f"\nSending payload:")
    print(f"  Score: {payload['score']}/{payload['total_questions']} ({payload['score']/payload['total_questions']*100}%)")
    print(f"  Time: {payload['time_taken']}s ({payload['time_taken']/payload['total_questions']}s per question)")
    
    try:
        response = requests.post(f"{BASE_URL}/quizzes/submit/adaptive", json=payload)
        response.raise_for_status()
        
        data = response.json()
        print(f"\n✅ Response received (Status: {response.status_code})")
        print(f"  Action: {data['action']}")
        print(f"  Message: {data['message']}")
        print(f"  New Difficulty: {data['new_difficulty']}")
        print(f"  Recommended Chapter: {data.get('recommended_chapter', 'N/A')}")
        
        # Assertions
        assert data["action"] == "ADVANCE", f"Expected ADVANCE but got {data['action']}"
        assert data["new_difficulty"] == 2, f"Expected difficulty 2 but got {data['new_difficulty']}"
        
        print("\n✅ TEST PASSED: Student can advance to next chapter")
        return True
        
    except requests.exceptions.RequestException as e:
        print(f"\n❌ HTTP Error: {e}")
        return False
    except AssertionError as e:
        print(f"\n❌ Assertion Failed: {e}")
        return False
    except Exception as e:
        print(f"\n❌ Unexpected Error: {e}")
        return False


def test_retry_with_topic():
    """Test RETRY scenario: Student scores < 70% with weak topic detection"""
    print("\n" + "="*60)
    print("TEST 2: RETRY SCENARIO (Low Score with Topic Analysis)")
    print("="*60)
    
    # Note: These question IDs should exist in your learning_content table
    # The backend will fetch their topic metadata to determine weak areas
    payload = {
        "student_id": "test-student-retry",
        "chapter": "Matter in Our Surroundings",
        "score": 2,
        "total_questions": 5,
        "time_taken": 250,  # 50s per question (slow)
        "mastery_level": 0.3,
        "difficulty_level": 1,
        "answers": [
            {"question_id": "q1", "is_correct": False},  # Will be analyzed for topic
            {"question_id": "q2", "is_correct": True},
            {"question_id": "q3", "is_correct": False},  # Will be analyzed for topic
            {"question_id": "q4", "is_correct": True},
            {"question_id": "q5", "is_correct": False},  # Will be analyzed for topic
        ]
    }
    
    print(f"\nSending payload:")
    print(f"  Score: {payload['score']}/{payload['total_questions']} ({payload['score']/payload['total_questions']*100}%)")
    print(f"  Time: {payload['time_taken']}s ({payload['time_taken']/payload['total_questions']}s per question)")
    
    try:
        response = requests.post(f"{BASE_URL}/quizzes/submit/adaptive", json=payload)
        response.raise_for_status()
        
        data = response.json()
        print(f"\n✅ Response received (Status: {response.status_code})")
        print(f"  Action: {data['action']}")
        print(f"  Message: {data['message']}")
        print(f"  New Difficulty: {data['new_difficulty']}")
        print(f"  Recommended Chapter: {data.get('recommended_chapter', 'N/A')}")
        print(f"  Recommended Section (Topic): {data.get('recommended_section', 'N/A')}")
        
        # Assertions
        assert data["action"] == "RETRY", f"Expected RETRY but got {data['action']}"
        assert data["new_difficulty"] == 0, f"Expected difficulty 0 (easy) but got {data['new_difficulty']}"
        
        if data.get('recommended_section'):
            print(f"\n✅ Weak topic detected: '{data['recommended_section']}'")
        else:
            print("\n⚠️  Warning: No weak topic detected (questions may not exist in DB)")
        
        print("\n✅ TEST PASSED: Student should retry with lowered difficulty")
        return True
        
    except requests.exceptions.RequestException as e:
        print(f"\n❌ HTTP Error: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"   Response: {e.response.text}")
        return False
    except AssertionError as e:
        print(f"\n❌ Assertion Failed: {e}")
        return False
    except Exception as e:
        print(f"\n❌ Unexpected Error: {e}")
        return False


def main():
    print("\n" + "🧪 ADAPTIVE TEST FLOW - BACKEND VERIFICATION".center(60))
    
    # Check backend connectivity
    try:
        health_check = requests.get(f"{BASE_URL.rsplit('/api/v1', 1)[0]}/")
        print(f"\n✅ Backend is reachable at {BASE_URL}")
    except Exception as e:
        print(f"\n❌ Cannot connect to backend at {BASE_URL}")
        print(f"   Error: {e}")
        print(f"\n   Make sure backend is running:")
        print(f"   cd backend && uvicorn app.main:app --reload")
        return
    
    # Run tests
    test1_passed = test_advance()
    test2_passed = test_retry_with_topic()
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    print(f"  ADVANCE scenario: {'✅ PASSED' if test1_passed else '❌ FAILED'}")
    print(f"  RETRY scenario:   {'✅ PASSED' if test2_passed else '❌ FAILED'}")
    
    if test1_passed and test2_passed:
        print("\n🎉 All tests passed! Adaptive flow is working correctly.")
    else:
        print("\n⚠️  Some tests failed. Review the errors above.")
    print()


if __name__ == "__main__":
    main()
