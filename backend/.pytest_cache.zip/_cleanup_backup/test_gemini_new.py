import google.generativeai as genai
import json

API_KEY = "AIzaSyCvluchfye2mn6jY7L-77HPC2OEfou_3-k"
genai.configure(api_key=API_KEY)
model = genai.GenerativeModel('models/gemini-1.5-flash')

def test_gemini():
    print("Testing Gemini with model: gemini-1.5-flash")
    prompt = "Hello, generate a JSON list with one object: {'test': 'success'}. Return ONLY the JSON."
    try:
        response = model.generate_content(prompt)
        print("Response received:")
        print(response.text)
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_gemini()
