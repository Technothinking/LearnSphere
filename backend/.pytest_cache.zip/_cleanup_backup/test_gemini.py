import google.generativeai as genai
import sys

API_KEY = "AIzaSyDlOJAlV1ADSFW1P1ect5DiFMuJoqHsLSQ"
genai.configure(api_key=API_KEY)

def test_model(model_name):
    print(f"Testing model: {model_name}...")
    try:
        model = genai.GenerativeModel(model_name)
        response = model.generate_content("Say hello in one word.")
        print(f"Response: {response.text.strip()}")
        return True
    except Exception as e:
        print(f"Error for {model_name}: {e}")
        return False

if __name__ == "__main__":
    # Test standard models
    models_to_test = ["gemini-1.5-flash", "models/gemini-1.5-flash", "models/gemini-2.5-flash"]
    for m in models_to_test:
        if test_model(m):
            print(f"SUCCESS: {m} is working.")
            break
        else:
            print(f"FAILED: {m}")
