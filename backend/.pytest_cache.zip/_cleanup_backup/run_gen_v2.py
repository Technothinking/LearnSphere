import asyncio
import os
import time
import json
import google.generativeai as genai
from app.services.content_service import ContentGenerationService
from app.core.database import supabase

# Configure Gemini for this script explicitly to ensure it works
API_KEY = "AIzaSyDlOJAlV1ADSFW1P1ect5DiFMuJoqHsLSQ"
genai.configure(api_key=API_KEY)
# Using 1.5 Pro for better reasoning and potentially more stable free tier behavior
model = genai.GenerativeModel('models/gemini-1.5-pro')

async def process_all_chapters():
    bucket_name = "Textbook"
    subject = "Physics" # General subject, will try to infer or use default
    
    print("Listing files in bucket 'Textbook'...")
    try:
        res = supabase.storage.from_(bucket_name).list()
    except Exception as e:
        print(f"Error listing bucket: {e}")
        return

    if not res:
        print("No files found.")
        return

    # Filter only PDF files
    pdfs = [f for f in res if f.get('name', '').lower().endswith('.pdf')]
    print(f"Found {len(pdfs)} PDF files.")

    for f in pdfs:
        fname = f.get('name')
        chapter_name = os.path.splitext(fname)[0].replace('_', ' ').strip()
        
        # Check if already processed
        try:
            check_res = supabase.table("common_test_questions").select("id", count="exact").eq("chapter", chapter_name).execute()
            if check_res.count and check_res.count >= 30:
                print(f"⏩ Skipping {chapter_name} - Already has {check_res.count} questions.")
                continue
        except Exception as e:
            print(f"⚠️ Check failed for {chapter_name}: {e}")

        print(f"\n--- Processing: {chapter_name} (File: {fname}) ---")
        
        try:
            # 1. Download PDF
            print(f"Downloading '{fname}'...")
            try:
                pdf_bytes = supabase.storage.from_(bucket_name).download(fname)
            except Exception as download_err:
                print(f"❌ Supabase Download Error for '{fname}': {download_err}")
                continue
            
            if not pdf_bytes:
                print(f"❌ Downloaded bytes are empty for '{fname}'")
                continue

            # 2. Extract Text
            print(f"Extracting text...")
            try:
                text = ContentGenerationService.extract_text_from_pdf(pdf_bytes)
            except Exception as extract_err:
                 print(f"❌ Extraction Error for '{fname}': {extract_err}")
                 continue
            
            print(f"Extracted {len(text)} characters.")
            
            if len(text) < 500:
                 print(f"❌ Text too short for {chapter_name}. Skipping.")
                 continue

            # 3. Generate Common Questions
            # We use a limited text chunk to stay under context limits and satisfy the free tier
            context_text = text[:20000] 
            
            prompt = f"""
            You are an expert Science teacher. Based on the provided textbook material for the chapter '{chapter_name}', generate exactly 30 EASY-level questions.
            
            Text Material:
            {context_text}
            
            Requirements:
            1. Total Questions: 30
            2. Difficulty: ALL questions must be EASY (basic recall, definitions, simple facts).
            3. Types Distribution:
               - 10 Multiple Choice (MCQ) - Provide 4 options (A, B, C, D) and the correct answer.
               - 10 Fill-in-the-blank - Provide a sentence with a blank and the correct word/phrase.
               - 10 True/False - Provide a simple statement and whether it is 'True' or 'False'.
            
            Output Format:
            Return ONLY a raw JSON list of objects. Each object must have these keys:
            {{
                "question_type": "multiple_choice" | "fill_blank" | "true_false",
                "subject": "Physics", 
                "chapter": "{chapter_name}",
                "data": {{
                    "question_text": "...",
                    "options": ["...", "...", "...", "..."], // For MCQ, 4 options. For others, empty list.
                    "answer": "..." // For MCQ: A, B, C, or D. For Fill/TF: the answer string.
                }}
            }}
            """
            
            print(f"Calling Gemini 1.5 Pro for {chapter_name}...")
            response = model.generate_content(prompt)
            res_text = response.text.strip()
            
            # Clean JSON
            if "```json" in res_text:
                res_text = res_text.split("```json")[1].split("```")[0].strip()
            elif "```" in res_text:
                res_text = res_text.split("```")[1].split("```")[0].strip()
            
            # Extract first [...] if there's other text
            start = res_text.find("[")
            end = res_text.rfind("]")
            if start != -1 and end != -1:
                res_text = res_text[start:end+1]
                
            questions = json.loads(res_text)
            print(f"Generated {len(questions)} questions.")

            if questions:
                # 4. Save to DB
                supabase.table("common_test_questions").insert(questions).execute()
                print(f"✅ Saved 30 questions for {chapter_name}.")
            
            # Cooldown to avoid 429 (Free tier Pro is ~2 RPM)
            print("Cooldown 35s...")
            time.sleep(35)

        except Exception as e:
            print(f"❌ Error for {chapter_name}: {e}")
            if "429" in str(e):
                print("🛑 Rate limit hit. Sleeping for 60s...")
                time.sleep(60)
            else:
                # Still sleep a bit to be safe
                time.sleep(10)

if __name__ == "__main__":
    asyncio.run(process_all_chapters())
