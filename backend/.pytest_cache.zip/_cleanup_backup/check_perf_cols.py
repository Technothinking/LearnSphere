from app.core.database import engine
from sqlalchemy import inspect

inspector = inspect(engine)
cols = [c['name'] for c in inspector.get_columns('performance_history')]
for c in cols:
    print(c)
