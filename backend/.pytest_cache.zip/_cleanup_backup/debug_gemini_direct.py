import google.generativeai as genai
import json

API_KEY = "AIzaSyDlOJAlV1ADSFW1P1ect5DiFMuJoqHsLSQ"
genai.configure(api_key=API_KEY)
model = genai.GenerativeModel('models/gemini-2.0-flash')

def debug_gemini():
    chapter = "Motion"
    subject = "Physics"
    text = "Motion is the change in position of an object with respect to time. Scalars have magnitude only. Vectors have magnitude and direction."
    
    prompt = f"Generate 5 easy questions for {chapter} in JSON list format [{{'question_text':'...', 'answer':'...'}}]"
    
    print(f"Calling Gemini with simplified prompt...")
    try:
        response = model.generate_content(prompt)
        print("\n--- RAW RESPONSE ---")
        print(response.text)
        print("--- END RAW ---")
        
        # Check if it's JSON
        try:
             res_json = json.loads(response.text.strip())
             print("Valid JSON detected!")
        except:
             print("Not valid JSON directly.")
             
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    debug_gemini()
