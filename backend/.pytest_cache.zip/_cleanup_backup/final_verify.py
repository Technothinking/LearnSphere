from app.core.database import supabase

print("=== TEXTBOOK TABLE ===")
tb = supabase.table('textbook').select('subject, chapter').execute()
for i in tb.data:
    print(f"{i['subject']:15} | {i['chapter']}")

print("\n=== TESTING COMMON TEST QUERY ===")
# Test with "Laws of Motion" directly
res = supabase.table('common_test_questions').select('*').eq('chapter', 'Laws of Motion').limit(3).execute()
print(f"Found {len(res.data)} questions for 'Laws of Motion'")

if res.data:
    print("\nFirst question preview:")
    print(f"  Type: {res.data[0]['question_type']}")
    print(f"  Question: {res.data[0]['data']['question_text'][:60]}...")
