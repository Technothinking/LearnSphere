import asyncio
import os
import time
import json
from app.services.content_service import ContentGenerationService
from app.core.database import supabase

async def process_all_chapters():
    bucket_name = "Textbook"
    subject = "Physics"
    
    print("Listing files in bucket 'Textbook'...")
    try:
        files = supabase.storage.from_(bucket_name).list()
    except Exception as e:
        print(f"Error listing bucket: {e}")
        return

    if not files:
        print("No files found.")
        return

    for f in files:
        fname = f.get('name')
        if not fname.lower().endswith('.pdf'):
            continue
            
        chapter_name = os.path.splitext(fname)[0].replace('_', ' ').title()
        
        # Check if already has 30 questions
        try:
            res = supabase.table("common_test_questions").select("id", count="exact").eq("chapter", chapter_name).execute()
            if res.count and res.count >= 30:
                print(f"⏩ Skipping {chapter_name} - Already has {res.count} questions.")
                continue
        except Exception as e:
            print(f"⚠️ Check failed for {chapter_name}: {e}")

        print(f"\n--- Generating Common Test for: {chapter_name} ---")
        
        try:
            # 1. Download PDF
            print(f"Downloading {fname}...")
            pdf_bytes = supabase.storage.from_(bucket_name).download(fname)
            
            if not pdf_bytes or len(pdf_bytes) < 100:
                print(f"❌ Failed to download {fname} (Empty or small file).")
                continue

            # 2. Extract Text
            text = ContentGenerationService.extract_text_from_pdf(pdf_bytes)
            print(f"Extracted {len(text)} characters.")
            
            if len(text) < 100:
                 print(f"❌ Too little text extracted from {fname}. Skipping.")
                 continue

            # 3. Generate ONLY Common Questions
            print(f"Calling Gemini (models/gemini-1.5-flash) for {chapter_name}...")
            common_questions = await ContentGenerationService.generate_common_test_questions(text, chapter_name, subject)
            
            if common_questions:
                mapped_common = []
                for q in common_questions:
                    mapped_common.append({
                        "subject": q.get("subject", subject),
                        "chapter": q.get("chapter", chapter_name),
                        "question_type": q.get("question_type", "multiple_choice"),
                        "data": q.get("data")
                    })
                
                # 4. Save to DB
                supabase.table("common_test_questions").insert(mapped_common).execute()
                print(f"✅ Successfully saved {len(mapped_common)} questions for {chapter_name}.")
            else:
                print(f"❌ No questions generated for {chapter_name} (Gemini returned empty).")

        except Exception as e:
            print(f"⚠️ Error processing {chapter_name}:")
            if "429" in str(e) or "quota" in str(e).lower():
                print("🛑 Rate limit hit. Sleeping for 120s...")
                time.sleep(120)
            else:
                print(f"   - Message: {e}")
        
        # Cooldown between chapters (STRICT 60s to avoid 429)
        print("Cooldown 60s...")
        time.sleep(60)

if __name__ == "__main__":
    asyncio.run(process_all_chapters())
