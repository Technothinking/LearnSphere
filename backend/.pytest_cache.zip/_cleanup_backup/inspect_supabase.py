from app.core.database import supabase

def inspect_learning_content():
    try:
        print("Fetching one row from learning_content...")
        response = supabase.table("learning_content").select("*").limit(1).execute()
        print(f"Data: {response.data}")
        
        if response.data:
            print(f"Columns: {response.data[0].keys()}")
        else:
            print("Table exists but is empty.")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    inspect_learning_content()
