from app.core.database import supabase

def check_names():
    print("--- TEXTBOOK TABLE ---")
    res_tb = supabase.table("textbook").select("chapter").execute()
    tb_names = [r['chapter'] for r in res_tb.data]
    for n in sorted(tb_names):
        print(f"|{n}| ({len(n)})")

    print("\n--- LEARNING CONTENT TABLE ---")
    res_lc = supabase.table("learning_content").select("chapter").execute()
    lc_names = sorted(list(set([r['chapter'] for r in res_lc.data])))
    for n in lc_names:
        print(f"|{n}| ({len(n)})")

    # Check student permissions for a specific student (the one from previous logs if possible)
    # student_id = "d16a5111-8fb7-4c22-bc4f-3ca587ed65f0"
    print("\n--- STUDENT PERMISSIONS (ALL) ---")
    res_perm = supabase.table("student_permissions").select("student_id", "completed_chapters").execute()
    for r in res_perm.data:
        print(f"Student: {r['student_id']}, Completed: {r['completed_chapters']}")

if __name__ == "__main__":
    check_names()
