from app.core.database import supabase
from collections import Counter

def verify_counts():
    try:
        # Fetch all content from common_test_questions (just id and chapter for speed)
        res = supabase.table("common_test_questions").select("chapter, question_type").execute()
        
        if not res.data:
            print("No data found in common_test_questions.")
            return

        cnt = Counter()
        type_cnt = Counter()
        
        for item in res.data:
            cnt[item['chapter']] += 1
            type_cnt[f"{item['chapter']} - {item.get('question_type', 'unknown')}"] += 1
            
        print("\n--- Common Test Questions Count ---")
        for chapter, count in cnt.items():
            print(f"Chapter: {chapter} | Total: {count}")
            
        print("\n--- Breakdown by Type ---")
        for key, count in type_cnt.items():
            print(f"{key}: {count}")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    verify_counts()
