from app.core.database import supabase

print("=" * 80)
print("TEXTBOOK TABLE CHAPTERS")
print("=" * 80)
tb = supabase.table('textbook').select('subject, chapter').execute()
textbook_chapters = {}
for i in tb.data:
    key = f"{i['subject']}"
    if key not in textbook_chapters:
        textbook_chapters[key] = []
    textbook_chapters[key].append(i['chapter'])

for subj in sorted(textbook_chapters.keys()):
    print(f"\n{subj}:")
    for chap in sorted(set(textbook_chapters[subj])):
        print(f"  TB: '{chap}'")

print("\n" + "=" * 80)
print("COMMON_TEST_QUESTIONS TABLE CHAPTERS")
print("=" * 80)
ct = supabase.table('common_test_questions').select('subject, chapter').execute()
ct_chapters = {}
for i in ct.data:
    key = f"{i['subject']}"
    if key not in ct_chapters:
        ct_chapters[key] = set()
    ct_chapters[key].add(i['chapter'])

for subj in sorted(ct_chapters.keys()):
    print(f"\n{subj}:")
    for chap in sorted(ct_chapters[subj]):
        print(f"  CT: '{chap}'")

print("\n" + "=" * 80)
print("MISMATCHES (chapters in textbook but NOT in common_test_questions)")
print("=" * 80)
for subj in textbook_chapters:
    tb_set = set(textbook_chapters[subj])
    ct_set = ct_chapters.get(subj, set())
    mismatches = tb_set - ct_set
    if mismatches:
        print(f"\n{subj}:")
        for chap in sorted(mismatches):
            print(f"  Textbook has: '{chap}'")
            # Try to find similar in CT
            for ct_chap in ct_set:
                if chap.lower().replace(' ', '').replace(',', '') == ct_chap.lower().replace(' ', '').replace(',', ''):
                    print(f"    -> Likely match in CT: '{ct_chap}'")
