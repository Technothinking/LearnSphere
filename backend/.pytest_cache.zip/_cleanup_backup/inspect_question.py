from app.core.database import supabase
import json

res = supabase.table('common_test_questions').select('*').limit(1).execute()
if res.data:
    question = res.data[0]
    print("Full question object:")
    print(json.dumps(question, indent=2, default=str))
    
    print("\n" + "=" * 60)
    print("Data field structure:")
    if 'data' in question:
        print(json.dumps(question['data'], indent=2, default=str))
