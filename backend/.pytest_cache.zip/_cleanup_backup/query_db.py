from app.core.database import supabase
import json
import sys

def run_query(query_str):
    try:
        # Simple search for fill-in-the-blanks style questions
        # or anything without 'options'
        response = supabase.table("learning_content").select("*").execute()
        
        count = 0
        for item in response.data:
            data = item.get('data', {})
            options = data.get('options', [])
            if not options:
                print(json.dumps(item, indent=2))
                return
        
        if count == 0:
            print("No questions without options found.")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    run_query(None)
