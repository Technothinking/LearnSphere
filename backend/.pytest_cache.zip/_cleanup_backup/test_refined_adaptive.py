from app.core.database import SessionLocal, supabase
from app.schemas.quiz_schema import AdaptiveTestSubmission
from app.api.v1.quizzes import submit_adaptive_test
from app.models.student import Student
from app.models.mastery import SubtopicMastery
import json

def test_fallback_logic():
    db = SessionLocal()
    student_id = "test_uuid_123"
    chapter = "Motion"
    
    # 1. Setup/Cleanup
    db.query(SubtopicMastery).filter(SubtopicMastery.student_id == student_id).delete()
    db.query(Student).filter(Student.id == student_id).delete()
    db.commit()
    
    # Create test student
    from app.services.student_service import create_student
    student = create_student(db, student_id, "test@test.com", 9)
    
    # 2. Simulate Common Test Submission with some failures
    # Assuming "Motion" has "Speed" and "Acceleration" topics
    submission = AdaptiveTestSubmission(
        student_id=student_id,
        email="test@test.com",
        chapter=chapter,
        subtopic=None, # Chapter-wide test
        score=6,
        total_questions=10,
        time_taken=200.0,
        mastery_level=0.5,
        difficulty_level=1,
        answers=[
            {"question_id": "q1", "is_correct": True, "topic": "Speed"},
            {"question_id": "q2", "is_correct": True, "topic": "Speed"},
            {"question_id": "q3", "is_correct": False, "topic": "Speed"},
            {"question_id": "q4", "is_correct": False, "topic": "Acceleration"},
            {"question_id": "q5", "is_correct": False, "topic": "Acceleration"},
            {"question_id": "q6", "is_correct": True, "topic": "Acceleration"},
            {"question_id": "q7", "is_correct": True, "topic": "Distance"},
            {"question_id": "q8", "is_correct": True, "topic": "Distance"},
            {"question_id": "q9", "is_correct": True, "topic": "Distance"},
            {"question_id": "q10", "is_correct": False, "topic": "Distance"}
        ]
    )
    
    print("\n[Submitting Simulated Common Test...]")
    response = submit_adaptive_test(submission, db)
    
    print(f"Action: {response.action}")
    print(f"Message: {response.message}")
    print(f"New Difficulty: {response.new_difficulty}")
    print(f"Fallback Topics: {response.fallback_topics}")
    
    # Verification
    assert "Speed" in response.fallback_topics # 2/3 = 66% < 70%
    assert "Acceleration" in response.fallback_topics # 1/3 = 33% < 70%
    assert "Distance" not in response.fallback_topics # 3/4 = 75% > 70%
    
    # The action and difficulty depends on RL or fallback. 
    # With score 6/10 (0.6 accuracy), fallback should return action 1 (Easy Test) -> RETRY / Diff 0
    # Our test student has accuracy 0.6, so fallback action_idx = 1
    
    print("\n[SUCCESS] Fallback Detection Verified!")
    
    # Check Mastery Updates
    mastery = db.query(SubtopicMastery).filter(SubtopicMastery.student_id == student_id).all()
    print("\n[DB Mastery Records]:")
    for m in mastery:
        print(f"Topic: {m.subtopic} | Accuracy: {m.accuracy:.2f} | Completed: {m.is_completed}")
    
    db.close()

if __name__ == "__main__":
    try:
        test_fallback_logic()
    except Exception as e:
        print(f"[FAIL] Verification Failed: {e}")
        import traceback
        traceback.print_exc()
