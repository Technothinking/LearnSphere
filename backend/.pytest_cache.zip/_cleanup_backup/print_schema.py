from app.core.database import engine
from sqlalchemy import inspect

inspector = inspect(engine)
for table in inspector.get_table_names():
    print(f"\nTABLE: {table}")
    for col in inspector.get_columns(table):
        print(f"  - {col['name']}")
