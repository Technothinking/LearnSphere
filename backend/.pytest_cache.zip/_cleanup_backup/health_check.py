import requests
import time

print("Testing backend endpoints...")

# Test 1: Chapters
print("\n1. GET /api/v1/quizzes/chapters?subject=Science")
start = time.time()
try:
    response = requests.get('http://localhost:8000/api/v1/quizzes/chapters?subject=Science', timeout=5)
    elapsed = time.time() - start
    print(f"   Status: {response.status_code} | Time: {elapsed:.2f}s")
    if response.status_code == 200:
        data = response.json()
        print(f"   Chapters returned: {len(data)}")
except requests.Timeout:
    print(f"   TIMEOUT after 5 seconds")
except Exception as e:
    print(f"   ERROR: {e}")

# Test 2: RL Next Action
print("\n2. GET /api/v1/rl/next-action/d16a5111-8fb7-4c22-bc4f-3ca587ed65f0")
start = time.time()
try:
    response = requests.get('http://localhost:8000/api/v1/rl/next-action/d16a5111-8fb7-4c22-bc4f-3ca587ed65f0', timeout=5)
    elapsed = time.time() - start
    print(f"   Status: {response.status_code} | Time: {elapsed:.2f}s")
except requests.Timeout:
    print(f"   TIMEOUT after 5 seconds")
except Exception as e:
    print(f"   ERROR: {e}")

# Test 3: Simple health check
print("\n3. GET /api/v1/quizzes/subjects")
start = time.time()
try:
    response = requests.get('http://localhost:8000/api/v1/quizzes/subjects', timeout=5)
    elapsed = time.time() - start
    print(f"   Status: {response.status_code} | Time: {elapsed:.2f}s")
except requests.Timeout:
    print(f"   TIMEOUT after 5 seconds")
except Exception as e:
    print(f"   ERROR: {e}")
