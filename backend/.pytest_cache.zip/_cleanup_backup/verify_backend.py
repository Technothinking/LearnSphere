import requests
import json
import time

BASE_URL = "http://127.0.0.1:8000/api/v1"

def test_check_content_types():
    print("Checking available content types...")
    try:
        response = requests.get(f"{BASE_URL}/quizzes/?limit=50")
        if response.status_code == 200:
            items = response.json()
            types = set(item.get('content_type', 'unknown') for item in items)
            print(f"Content Types Found: {types}")
        else:
             print("Failed to fetch items")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    print("Starting verification (Ensure backend is running at localhost:8000)...")
    test_check_content_types()
